function save_name(docid)
{
    nametitle = $('#nametitle').val();
    firstname = $('#firstname').val();
    surname = $('#surname').val();
    if(nametitle <= 0 || firstname.length <= 0)
    {
        $('#alertmessage').text("Check full name...!!!!");
    }
    else
    {
        if(surname.length <= 0 ) surname = '';
        var request = $.ajax({
            url: '{{url("savedocprofile")}}/' + nametitle + '/' + firstname + '/' + surname + '/' + docid,
            success: function (response) {alert(response);
                if(response == 1){ $('#alertmessage').text("Profile saved successfully..!!"); }
                }
                //alert(response[0]["time"]);
        });
        $('#displayalert').modal('show');
        $('#namefld').show();
        $('#namelbl').hide();
        //$('#alertmessage').text("Successfully Saved..!!");
    }
}