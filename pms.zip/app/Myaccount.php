<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Myaccount extends Model
{
    //
    protected $table = 'registration_details';
    protected $fillable = ['user_id','nametitle','firstname','lastnametitle','lastname','surname','dob','sourceofreference','referredby'];
}
