<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class doctorcomm extends Model
{
    //
    protected $table = 'doctor_communication';
    protected $fillable  = ['doctor_id','contactnumber','voice_call','sms','whatsapp','priority','created_at','updated_at'];
}
