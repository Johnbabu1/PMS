<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\registration;
use Carbon\Carbon;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use Hash;
use Mail;
use DB;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */

//    protected $redirectPath = 'auth/login';
//    protected $loginPath = 'auth/login';
    protected $redirectTo = '/';

    public function index()
    {
        //
        return view('auth/login');
    }
    public function __construct()
    {
        $this->middleware('guest', ['except' => 'getLogout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [

            'nametitle' => 'required|max:255',
            'firstname' => 'required|max:255',
            'lastnametitle' => 'required|max:255',
            'lastname' => 'required|max:255',
            'dob' => 'required|max:255',
            'Mobile_number' => 'required|max:12|min:6',
            'email' => 'required|email|max:255',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
//        $usercnt = DB::table('users')->join('registration_details','registration_details.id', '=', 'users.registerid')->where('users.created', Carbon::today()->format('Y-m-d'))->where('registration_details.branchcode',$data['branchcode'])->count();
//        $usercnt = $usercnt + 1;
//        $f2d = sprintf("%02d",$usercnt);
//        $brcode = sprintf("%02d",$data['branchcode']);
//        $nme = strtoupper(substr($data['firstname'], 0,2));
//        $dt = date('dmy');
//        $username = $f2d.$brcode.$nme.$dt;

        $date1 = str_replace('/', '-', $data['dob']);
        $appdate = date('Y-m-d', strtotime($date1));

        $user = User::create([
            'name' => $data['firstname'],
            'email' => $data['email'],
            'password' => bcrypt($data['firstname']),
            'Mobile_number' => $data['Mobile_number'],
            /*'registerid' => $registration->id,*/
            'created' => date('Y-m-d'),
            'Role'     => 'Client',
            'remember_token' => $data['_token']
        ]);

        return registration::create([
            'user_id' => $user->id,
            'nametitle' => $data['nametitle'],
            'firstname' => $data['firstname'],
            'lastnametitle' => $data['lastnametitle'],
            'lastname' => $data['lastname'],
            'surname' => $data['surname'],
            'dob' => $appdate,
            'sourceofreference' => $data['sourceofreference'],
            'branchcode' => $data['branchcode'],
            'referredby' => $data['referredby']
        ]);
//

//
        \session()->flash('alert-success', 'Registration successful. You will receive your Username and Password shortly. !!');
//       if ($userreg->save()) {
//        Mail::send('emails.registration',['data'=>$data,'username'=>$username],function($mail) use ($request){
//            $mail->to($request['email'],$request['name'])->from('johnbabu19@gmail.com')->subject('Welcome');
//        } );
    }
    protected function authenticated($request, $user)
    {
        if($user->Role === 'admin') {
            return redirect()->intended('/admin_path_here');
        }

        return redirect()->intended('/path_for_normal_user');
    }

}
