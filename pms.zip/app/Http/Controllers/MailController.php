<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Mail;
use App\User;

class MailController extends Controller
{
    //
    public function index()
    {
        return view('emails.registration');
    }
    public function createRegistration(Request $request){
        $user = new User;
    }
}
