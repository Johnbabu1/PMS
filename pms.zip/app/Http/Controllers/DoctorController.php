<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use App\doctoravailability;
use App\sourceofreference_model;
use Illuminate\Support\Facades\Auth;
use DB;
use Carbon\Carbon;
use Mail;
use App\appoinment_timemodel;
use Validator, Input, Redirect, Url;

class DoctorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin')
            {
                $userqry = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.Role', '!=', "Client")->where('users.delet','=',"0")->where('users.Role', '!=', "super_admin");
                if(Auth::User()->Role == 'admin') {
                    $userqry = $userqry->where('users.Role', '!=', 'admin');
                }
                $userlist = $userqry->where('users.Role', '=','Doctor')->get();
                //$userlist = $userqry->where('users.Role', '=','Doctor')->get();
                return view('admin/doctorslist')->with('userlist',$userlist);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return view('auth/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin')
            {
                $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
                $branches = DB::table("branches")->where('delet','0')->where('branchname','!=','all')->get();
                $userlist = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.Role', '=', "Doctor")->orWhere('users.Role', '=', "Staff")->get();
                return view('admin/adddoctor')->with('sourcelist', $sourcelist)->with('branches', $branches);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('auth/login');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        print_r($request->closed);

        $day = array(0=>'Sunday', 1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday');

        $avail = new doctoravailability();
        $avail::where('user_id', $request->doctorid)->where('branchcode', $request->branch)->delete();
        for($i=0;$i<count($day);$i++){
            if(in_array($day[$i].'closed',$request->closed)){
                $avail::create([
                    'user_id' => $request->doctorid,
                    'branchcode' => $request->branch,
                    'day' => $day[$i],
                    'fhour'=> '00',
                    'fmin'=> '00',
                    'fap'=> '00',
                    'thour'=> '00',
                    'tmin'=> '00',
                    'tap'=> '00',
                    'day_off'=>'yes',
                    'created_by'=>Auth::User()->id,
                    'created_at'=>date('Y-m-d h:i:s')
                ]);

            }
            else{
                $fromh = $day[$i].'FromH';$fromm = $day[$i].'FromM'; $fromap= $day[$i].'FromAP';
                $toh = $day[$i].'ToH';$tom = $day[$i].'ToM';$toap = $day[$i].'ToAP';

                $avail::create([
                    'user_id' => $request->doctorid,
                    'branchcode' => $request->branch,
                    'day' => $day[$i],
                    'fhour'=> $request->$fromh,
                    'fmin'=> $request->$fromm,
                    'fap'=> $request->$fromap,
                    'thour'=> $request->$toh,
                    'tmin'=> $request->$tom,
                    'tap'=> $request->$toap,
                    'day_off'=>'no',
                    'created_by'=>Auth::User()->id,
                    'created_at'=>date('Y-m-d h:i:s')
                ]);
            }
        }
        return redirect()->action('StaffController@create');;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        //
        if(Auth::Check()) {

            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'Doctor' || Auth::User()->Role == 'super_admin') {

                $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
                $edituserdet = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.id', '=', $id)->where('users.delet','=',"0")->get();

                $doctorcontact = DB::table('doctor_communication')->where('doctor_id',$id)->select('*')->get();
                $docdonotdisturbs = DB::table('doctor_donot_disturb')->where('doctor_id',$id)->select('*')->get();

                $i=0;
                foreach($doctorcontact as $contact){

                    $dccontact['id'][$i] = $contact->id;
                    $dccontact['doc_id'][$i] = $contact->doctor_id;
                    $dccontact['contactnum'][$i] = $contact->contactnumber;
                    $dccontact['voicecl'][$i] = $contact->voice_call;
                    $dccontact['sms'][$i] = $contact->sms;
                    $dccontact['whatsapp'][$i] = $contact->whatsapp;
                    $dccontact['priority'][$i] = $contact->priority;
                    $i++;
                }
                return view('admin/editstaff')->with('edituserdet', $edituserdet)->with('dccontact',$doctorcontact)->with('docdonotdisturbs',$docdonotdisturbs)->with('sourcelist',$sourcelist);
            } else {
                return view('auth/login');
            }
        }
        else {
            return view('auth/login');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {

            $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
            $edituserdet = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.id', '=', $id)->where('users.delet','=',"0")->get();

            return view('admin/editstaffdet')->with('edituserdet', $edituserdet)->with('sourcelist',$sourcelist);
        } else {
            return view('auth/login');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $validate = Validator::make($request->all(), [
            /*'dob' => 'required',*/
            'sourceofreference' => 'required',
            'user_group' => 'required',
            'occupation' => 'required'
        ]);

        if ($validate->fails()) {

            //$url = URL::route('StaffController@index', array('#docothers'));
            return redirect('editstaff/'.$id.'#docothers')
                ->withErrors($validate)
                ->withInput();
        }

        $date1 = str_replace('/', '-', $request->dob);
        $appdate = date('Y-m-d', strtotime($date1));
        if(Auth::Check()) {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'Doctor' || Auth::User()->Role == 'super_admin') {

                $userdet = User::find($id);
                /*$userdet->Mobile_number = $request->Mobile_number;
                $userdet->email = $request->email;*/
                $userdet->Role  = $request->user_group;
                $userdet->save();

                $reguserdet = registration::find($userdet->registerid);
                $reguserdet->sourceofreference = $request->sourceofreference;
                $reguserdet->referredby = $request->referredby;

                $reguserdet->designation = $request->occupation;
                /*$reguserdet->dob = $appdate;*/
                $reguserdet->save();

                $request->session()->flash('alert-success', 'Employee Details successfully updated!');
                return redirect()->action('StaffController@index');
            } else {
                return redirect('myaccount');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    //Update Staff details as deleted
    public function deletebulkstaff(Request $request)
    {
        foreach($request->userrow as $rowid) {
            //$delappoinment = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.id',$rowid)->update(['users.delet'=>1,'users.updated_at'=>date('Y-m-d'),'registration_details.delet'=>1]);
            $delappoinment = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.id',$rowid)->delete();
        }
        $request->session()->flash('alert-success', 'Staff deleted successfully!');
        return redirect()->action('StaffController@index');
    }
}
