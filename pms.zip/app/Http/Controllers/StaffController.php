<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use App\sourceofreference_model;
use Illuminate\Support\Facades\Auth;
use DB;
use Carbon\Carbon;
use Mail;
use App\appoinment_timemodel;
use Validator, Input, Redirect, Url;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //

        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin')
            {
                $userqry = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.Role', '!=', "Client")->where('users.Role', '!=', "Doctor")->where('users.Role', '!=', "host")->where('users.delet','=',"0")->where('users.Role', '!=', "super_admin");
                if(Auth::User()->Role == 'admin')
                    $userqry = $userqry->where('users.Role', '!=', 'admin');

                $userlist = $userqry->get();
                return view('admin/stafflisting')->with('userlist',$userlist);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return view('auth/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $branches = DB::table("branches")->where('delet','0')->where('branchname','!=','all')->get();
        return view('admin/docavailability')->with('branches',$branches);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

        $date1 = str_replace('/', '-', $request->dob);
        $appdate = date('Y-m-d', strtotime($date1));
        $this->validate($request, [
            'nametitle' => 'required|max:255',
            'firstname' => 'required|max:255',
            'lastnametitle' => 'required|max:255',
            'lastname' => 'required|max:255',
            'dob' => 'required|max:255',
            'Mobile_number' => 'required|max:14|min:7',
            'email' => 'required|email|max:255',
            /*'user_group' => 'required',*/
            'occupation' => 'required'
        ]);

        $usercnt = DB::table('users')->join('registration_details','registration_details.id', '=', 'users.registerid')->where('users.created', Carbon::today()->format('Y-m-d'))->where('registration_details.branchcode',$request['branchcode'])->count();
        $usercnt = $usercnt + 1;
        $f2d = sprintf("%02d",$usercnt);
        $brcode = sprintf("%02d",$request['branchcode']);

        $data = $request['firstname'];
        $findme   = '.';

        $pos = strpos($data, $findme);
        $whatIWant = str_replace(' ', '', $data);
        if($pos < 4)
        {
            $strcnt = substr_count($whatIWant , ".");
            for($i=0;$i<$strcnt;$i++)
            {
                $whatIWant = substr($whatIWant , strpos($whatIWant , ".") + 1);
            }
            //$whatIWant = substr($data, strpos($data, ".") + 1 );
        }

        $nme = strtoupper(substr($whatIWant, 0,2));
        //$nme = strtoupper(substr($request['firstname'], 0,2));
        $dt = date('dmy');
        $username = $f2d.$brcode.$nme.$dt;


        $registration = registration::create([
            'nametitle' => $request['nametitle'],
            'firstname' => ucwords($request['firstname']),
            'lastnametitle' => ucwords($request['lastnametitle']),
            'lastname' => ucwords($request['lastname']),
            /*'surname' => $request['surname'],*/
            'dob' => $appdate,
            'sourceofreference' => $request['sourceofreference'],
            'designation' => ucwords($request['occupation']),
            'branchcode' => $request['branchcode'],
            'referredby' => ucwords($request['referredby'])
        ]);
//
        $user = User::create([
            'name' => $username,
            'email' => $request['email'],
            'password' => bcrypt(preg_replace('/\s+/', '', $request['firstname'])),
            'Mobile_number' => $request['Mobile_number'],
            'registerid' => $registration->id,
            'Role'     => $request['user_group'],
            'created'  => date('Y-m-d'),
            'remember_token' => $request['_token'],
            'approval' => 1
        ]);
//
        $request->username = $username;
        $request->useremail = $request['email'];
        $request->password =  preg_replace('/\s+/', '', $request['firstname']);
//       if ($userreg->save()) {

        if($request['user_group'] == 'Doctor'){
            Mail::send('emails.DoctorReg',['data'=>$request],function($mail) use ($request){
                $mail->to($request['email'],$request['name'])->from(Auth::user()->email)->subject('Welcome To Evident Dental');
            } );

            Mail::send('emails.DoctorSupport',['data'=>$request],function($mail) use ($request){
                $mail->to($request['email'],$request['name'])->from(Auth::user()->email)->subject('Evident Dental Support System');
            } );
        }
        elseif($request['user_group'] == 'admin'){
            Mail::send('emails.AdminReg',['data'=>$request],function($mail) use ($request){
                $mail->to($request['email'],$request['name'])->from(Auth::user()->email)->subject('Welcome To Evident Dental');
            } );

            Mail::send('emails.AdminSupport',['data'=>$request],function($mail) use ($request){
                $mail->to($request['email'],$request['name'])->from(Auth::user()->email)->subject('Evident Dental Support System');
            });
        }
        elseif($request['user_group'] == 'Staff'){
            Mail::send('emails.staffreg',['data'=>$request],function($mail) use ($request){
                $mail->to($request['email'],$request['name'])->from(Auth::user()->email)->subject('Welcome To Evident Dental');
            } );

            Mail::send('emails.StaffSupport',['data'=>$request],function($mail) use ($request){
                $mail->to($request['email'],$request['name'])->from(Auth::user()->email)->subject('Evident Dental Support System');
            });
        }
        $request->session()->flash('alert-success', 'Employee registered successfully.');
        $request->session()->put('doctorinsid', $user->id);
        return redirect()->route('editstaff.create');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        //
        if(Auth::Check()) {

            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'Doctor' || Auth::User()->Role == 'super_admin') {
                $accountdetails = new User;
                $userdetails = new registration;
                $allvalue = $userdetails::find(Auth::user()->registerid);
                $account = $accountdetails::find(Auth::user()->id);
                $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
                $edituserdet = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.id', '=', $id)->where('users.delet','=',"0")->get();

                $timings = new appoinment_timemodel;
                $apptimings = $timings::all();
                $branches = DB::table("branches")->where('delet','0')->where('branchname','!=','all')->get();
                //$staffallvalue = $userdetails::find($id);
                //$staffaccount = $accountdetails::find($id);
                $doctorcontact = DB::table('doctor_communication')->where('doctor_id',$id)->select('*')->get();
                $docdonotdisturbs = DB::table('doctor_donot_disturb')->where('doctor_id',$id)->select('*')->get();

                $i=0;
                foreach($doctorcontact as $contact){

                    $dccontact['id'][$i] = $contact->id;
                    $dccontact['doc_id'][$i] = $contact->doctor_id;
                    $dccontact['contactnum'][$i] = $contact->contactnumber;
                    $dccontact['voicecl'][$i] = $contact->voice_call;
                    $dccontact['sms'][$i] = $contact->sms;
                    $dccontact['whatsapp'][$i] = $contact->whatsapp;
                    $dccontact['priority'][$i] = $contact->priority;
                    $i++;
                }
                return view('admin/editstaff')->with('account', $account)->with('allvalue', $allvalue)->with('edituserdet', $edituserdet)->with('dccontact',$doctorcontact)->with('timings',$apptimings)->with('docdonotdisturbs',$docdonotdisturbs)->with('sourcelist',$sourcelist)->with('branches',$branches);
            } else {
                return view('auth/login');
            }
        }
        else {
            return view('auth/login');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
            $accountdetails = new User;
            $userdetails = new registration;
            $allvalue = $userdetails::find(Auth::user()->registerid);
            $account = $accountdetails::find(Auth::user()->id);
            $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
            $edituserdet = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.id', '=', $id)->where('users.delet','=',"0")->get();

            return view('admin/editstaffdet')->with('account', $account)->with('allvalue', $allvalue)->with('edituserdet', $edituserdet)->with('sourcelist',$sourcelist);
        } else {
            return view('auth/login');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $validate = Validator::make($request->all(), [
            /*'dob' => 'required',*/
            'sourceofreference' => 'required',
            'user_group' => 'required',
            'designation' => 'required'
        ]);

        if ($validate->fails()) {

            //$url = URL::route('StaffController@index', array('#docothers'));
            if(Auth::User()->Role == 'Doctor'){
                return redirect('myaccount#docothers')
                    ->withErrors($validate)
                    ->withInput();
            }else{
                return redirect('editstaff/'.$id.'#docothers')
                    ->withErrors($validate)
                    ->withInput();
            }

        }

        $date1 = str_replace('/', '-', $request->dob);
        $appdate = date('Y-m-d', strtotime($date1));
        if(Auth::Check()) {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'Doctor' || Auth::User()->Role == 'super_admin') {

                $userdet = User::find($id);
                /*$userdet->Mobile_number = $request->Mobile_number;
                $userdet->email = $request->email;*/
                $userdet->Role  = $request->user_group;
                $userdet->save();

                $reguserdet = registration::find($userdet->registerid);
                $reguserdet->sourceofreference = $request->sourceofreference;
                $reguserdet->referredby = $request->referredby;

                $reguserdet->designation = $request->designation;
                /*$reguserdet->dob = $appdate;*/
                $reguserdet->save();

                $request->session()->flash('alert-success', 'Employee Details successfully updated!');
                return redirect()->action('StaffController@index');
            } else {
                return redirect('myaccount');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    //Update Staff details as deleted
    public function deletebulkstaff(Request $request)
    {
        foreach($request->userrow as $rowid) {
            //$delappoinment = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.id',$rowid)->update(['users.delet'=>1,'users.updated_at'=>date('Y-m-d'),'registration_details.delet'=>1]);
            $delappoinment = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.id',$rowid)->delete();
        }
        $request->session()->flash('alert-success', 'Staff deleted successfully!');
        return redirect()->action('StaffController@index');
    }
}
