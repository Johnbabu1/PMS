<?php

namespace App\Http\Controllers;

use App\Sourceofreference_model;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use Illuminate\Support\Facades\Auth;
use App\doctorcomm;

class SourceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {

                $sourceofref = new Sourceofreference_model();
                $sourcelist = $sourceofref::get()->where('hide','no');
                return view('admin/source_of_ref')->with('sourcelist', $sourcelist);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('myaccount');
        }
        //return view('myaccount');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Block to store doctor communication details
        if(Auth::Check()) {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
                $this->validate($request, [
                    'sourceofref' => 'required',
                ]);


                $sourceofref = new Sourceofreference_model();
                $sourceofref->sourceofreference = $request->sourceofref;
                $sourceofref->hide = 'no';
                $sourceofref->created_by = Auth::user()->id;
                $sourceofref->save();

                $request->session()->flash('alert-success', 'Source of Reference added successfully.');
                return redirect('sourceofref');
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('myaccount');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
