<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use Illuminate\Support\Facades\Auth;
use App\appoinment_timemodel;

class MyaccountController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    /* Constructor*/
    public function __construct()
    {

    }

    public function index()
    {

        //
        if(Auth::check())
        {
            if(Auth::User()->Role == 'Doctor') {

                $accountdetails = new User;
                $userdetails = new registration;
                $timings = new appoinment_timemodel;
                $apptimings = $timings::all();
                $allvalue = $userdetails::find(Auth::user()->registerid);
                $account = $accountdetails::find(Auth::user()->id);
                $branches = DB::table("branches")->where('delet','0')->where('branchname','!=','all')->get();

                $doctorcontact = DB::table('doctor_communication')->where('doctor_id', Auth::user()->id)->select('*')->get();
                $docdonotdisturbs = DB::table('doctor_donot_disturb')->where('doctor_id', Auth::user()->id)->select('*')->get();

                //Changed doctor myaccount page
                $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
                $edituserdet = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.id', '=', Auth::user()->id)->where('users.delet','=',"0")->get();

                $i = 0;
                foreach ($doctorcontact as $contact) {

                    $dccontact['id'][$i] = $contact->id;
                    $dccontact['doc_id'][$i] = $contact->doctor_id;
                    $dccontact['contactnum'][$i] = $contact->contactnumber;
                    $dccontact['voicecl'][$i] = $contact->voice_call;
                    $dccontact['sms'][$i] = $contact->sms;
                    $dccontact['whatsapp'][$i] = $contact->whatsapp;
                    $dccontact['priority'][$i] = $contact->priority;
                    $i++;
                }
                //return redirect('docappoinmentlist');
                return view('doctor/myaccount')->with('allvalue', $allvalue)->with('account', $account)->with('edituserdet', $edituserdet)->with('dccontact', $doctorcontact)->with('timings', $apptimings)->with('docdonotdisturbs', $docdonotdisturbs)->with('sourcelist',$sourcelist)->with('branches', $branches);
            }
            if(Auth::User()->Role == 'Host') {
                $accountdetails = new User;
                $userdetails = new registration;
                $allvalue = $userdetails::find(Auth::user()->registerid);
                $account = $accountdetails::find(Auth::user()->id);
                $branches = DB::table("branches")->where('delet','0')->where('branchname','!=','all')->get();
                $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
                $edituserdet = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.id', '=', Auth::user()->id)->where('users.delet','=',"0")->get();

                return view('host/edithost')->with('account', $account)->with('allvalue', $allvalue)->with('edituserdet', $edituserdet)->with('sourcelist',$sourcelist)->with('branches',$branches);
            }
        }
        else{
            return view('auth/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //showing User details
        $accountdetails = new User;
        $userdetails = new registration;
        $allvalue = $userdetails::find($id);
        return $allvalue;
        //return view('myaccount')->with('allvalues',$allvalue);
    }

    /**Function to show profile data */
    public function showprofile(Request $request, $id)
    {
        $value = $request->session()->get('key');
    }
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
