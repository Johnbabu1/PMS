<?php

namespace App\Http\Controllers;

use App\Sourceofreference_model;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use Illuminate\Support\Facades\Auth;
use App\doctorcomm;
use App\Proceduredetails_model;

class ProcedureController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
                $procedure = new Proceduredetails_model();
                $procedurelist = $procedure::get()->where('hide','no');
                return view('admin/procedurelist')->with('procedurelist', $procedurelist);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('myaccount');
        }
        //return view('myaccount');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {

                return view('admin/addprocedure');
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('myaccount');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Block to store doctor communication details
        if(Auth::Check()) {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
                $this->validate($request, [
                    'procedurename' => 'required',
                    'procedureprice' => 'required'
                ]);


                $procedures = new Proceduredetails_model();
                $procedures->procedure_name = $request->procedurename;
                $procedures->procedure_price = $request->procedureprice;
                $procedures->hide = 'no';
                $procedures->created_by = Auth::user()->id;
                $procedures->save();

                $request->session()->flash('alert-success', 'Procedure Created Successfully.');
                return redirect('procedures');
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('myaccount');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {

                $procedures = new Proceduredetails_model();
                $procedure = $procedures::where('id', $id)->get();

                return view('admin/editprocedure')->with('procedure', $procedure);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('myaccount');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        if(Auth::Check()) {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
                $this->validate($request, [
                    'procedurename' => 'required',
                    'procedureprice' => 'required'
                ]);

                $procedures = new Proceduredetails_model();
                $updprocedure = $procedures::find($id);
                $updprocedure->procedure_name = $request->procedurename;
                $updprocedure->procedure_price = $request->procedureprice;
                $updprocedure->updated_by = Auth::user()->id;
                $updprocedure->save();

                $request->session()->flash('alert-success', 'Procedure Updated Successfully.');
                return redirect('procedures');
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('myaccount');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if(Auth::Check()) {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
                $procedures = new Proceduredetails_model();
                $updprocedure = $procedures::find($id);
                $updprocedure->hide = 'yes';
                $updprocedure->updated_by = Auth::user()->id;
                $updprocedure->save();
                \session()->flash('alert-success', 'Procedure deleted successfully.');
                return redirect('procedures');
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('myaccount');
        }

    }
}
