<?php

namespace App\Http\Controllers;

use App\appoinment_timemodel;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use App\FixAppoinment;
use App\AppointmentStatusModel;
use Illuminate\Support\Facades\Auth;
use DB;
use Carbon\Carbon;
use Mail;
use App\Inspection_model;
use App\Remainder_model;

class AppoinmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin' || Auth::User()->Role == 'Host')
            {
                $patientlist = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('Role','Client')->lists('registration_details.firstname','users.id');
                $hostlist = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.Role','Host')->lists(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'users.id');
                $doctors = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('Role','Doctor')->lists(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'users.id');
                $apptimings = DB::table('appoinment_time')->lists('timings','id');
                return view('admin/fixappoinment')->with('patientlist',$patientlist)->with('doctors',$doctors)->with('hostlist',$hostlist)->with('apptimings', $apptimings);
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('auth/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $this->validate($request, [
            'Client' => 'required|max:255',
            'doctors' => 'required|max:255',
            'appdate' => 'required|max:255',
            'branchcode' => 'required|max:255',
            /*'apptime' => 'required|max:10',*/
            'Host' => 'required'

        ]);
        $date1 = str_replace('/', '-', $request->appdate);
        $appdate = date('Y-m-d', strtotime($date1));
        //$availability = DB::table('appoinments')->where('doctorid',$request->doctors)->where('appoinment_time',$request->apptime)->where('appoinmentdate',$appdate)->count();
        //$chkappoinments = DB::table("appoinments")->select()->where('appoinmentdate', $appdate)->where('appoinment_time', $request->apptime)->where('branchcode', $request->branchcode);
        //$cnt = $chkappoinments->count();
        //if($availability <=0 && $cnt < 2) {

        $appointmentdet = \session()->get('tempapp');
        /*echo $appointmentdet['start'];
        print_r($appointmentdet);exit;*/

        $appoinments = new FixAppoinment;
        $appoinments->patientid = $request->Client;
        $appoinments->doctorid = $request->doctors;
        $appoinments->appoinmentdate = $appdate;
        /*$appoinments->appoinment_time = $request->apptime;*/
        $appoinments->branchcode = $request->branchcode;
        $appoinments->clientnote = $appointmentdet['appoint'];;
        $appoinments->host_name = $request->Host;
        $appoinments->appointment_desc = $appointmentdet['appoint'];
        $appoinments->appointment_start = $appointmentdet['start'];
        $appoinments->appointment_end = $appointmentdet['end'];
        $appoinments->created_by = Auth::user()->id;
        $appoinments->updated_at = date("Y-m-d H:i:s");
        $appoinments->created_at = date("Y-m-d H:i:s");
        $appoinments->save();

        $ins_id = $appoinments->id;

        //Add appointment status
        $appstatus = new AppointmentStatusModel();
        $appstatus->appointment_id = $ins_id;
        $appstatus->appointment_status = 'open';
        $appstatus->created_by = Auth::user()->id;
        $appstatus->updated_at = date("Y-m-d H:i:s");
        $appstatus->created_at = date("Y-m-d H:i:s");
        $appstatus->save();

        if(isset($request['prevappid'])){
            $inspection = new Inspection_model();
            $upd_inspection = $inspection::where('appoinment_id', $request['prevappid'])->first();
            $upd_inspection->next_appoinment_id = $ins_id;
            $upd_inspection->save();
        }

        //Remainder to host and doctor
        $get_remainder = DB::table('inspection_details')->select('inspection_details.*','appoinments.doctorid','appoinments.host_name','appoinments.appoinmentdate')->join('appoinments', 'inspection_details.appoinment_id','=','appoinments.id')->where('appoinments.patientid',$request->Client)->orderBy('inspection_details.created_at','DESC')->limit(1)->first();
        if(count($get_remainder) > 0) {
            $hostremainder = new Remainder_model();
            $hostremainder->user_id = $get_remainder->host_name;
            $hostremainder->remainder_title = "Remainder for Todays Appointment";
            $hostremainder->remainder_description = $get_remainder->host_note;
            $hostremainder->remainder_date = $appdate;
            $hostremainder->remainder_time = "9 AM";
            $hostremainder->status = 'active';
            $hostremainder->created_by = Auth::User()->id;
            $hostremainder->save();

            //Remainder to host and doctor
            $docremainder = new Remainder_model();
            $docremainder->user_id = $get_remainder->doctorid;
            $docremainder->remainder_title = "Remainder for an Appointment";
            $docremainder->remainder_description = $get_remainder->doctor_note;
            $docremainder->remainder_date = $appdate;
            $docremainder->remainder_time = "9 AM";
            $docremainder->status = 'active';
            $docremainder->created_by = Auth::User()->id;
            $docremainder->save();
        }
        $request->session()->flash('alert-success', 'Appointment Fixed successfully!');
        return redirect()->route('appoinmentlist');
        /*}
        else{
            if($cnt >= 2)
            {
                $request->session()->flash('alert-danger', 'Already 2 appoinments are fixed for this date and time. Select another time or date!');
            }
            else {
                $request->session()->flash('alert-danger', 'This date and time already fixed for this doctor. Kindly re schedule the appointment!');
            }
        return redirect('fixappoinment');
        }*/


}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $appoinments = new FixAppoinment;
        $doctors = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('Role','Doctor')->lists(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'users.id');
        $hostlist = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.Role','Host')->lists(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'users.id');

        $appoinmentlist = $appoinments::find($id);
        $apptimings = DB::table('appoinment_time')->lists('timings','id');
        //print_r($docavail);
        $clientid = 0;

        //Patient details
        $clientdet = DB::table('registration_details')->join('users','users.registerid','=','registration_details.id')->where('users.id','=',$appoinmentlist->patientid)->get();
        //return $clientdet;
        foreach($clientdet as $client){
            $clientdet['id'] = $client->id;
            $clientdet['nametitle'] = $client->nametitle;
            $clientdet['firstname'] = $client->firstname;
            $clientdet['lastnametitle'] = $client->lastnametitle;
            $clientdet['lastname'] = $client->lastname;
            $clientdet['email'] = $client->email;
            $clientdet['Mobile_number'] = $client->Mobile_number;
        }
        return view('admin/editappoinment')->with('appoinmentlist',$appoinmentlist)->with('hostlist', $hostlist)->with('doctors', $doctors)->with('apptimings', $apptimings)->with('clientdet',$clientdet)->with('clientid',$clientid);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $appoinments = new FixAppoinment;
        $doctors = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('Role','Doctor')->lists(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'users.id');
        $hostlist = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.Role','Host')->lists(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'users.id');

        $appoinmentlist = $appoinments::find($id);
        $apptimings = DB::table('appoinment_time')->lists('timings','id');
        //print_r($docavail);
        $clientid = 0;
        $purpose_nxt_app = DB::table('inspection_details')->select('purpose_nxt_app')->where('appoinment_id',$id )->value('purpose_nxt_app');

        //Patient details
        $clientdet = DB::table('registration_details')->join('users','users.registerid','=','registration_details.id')->where('users.id','=',$appoinmentlist->patientid)->get();
        //return $clientdet;
        foreach($clientdet as $client){
            $clientdet1['id'] = $client->id;
            $clientdet1['nametitle'] = $client->nametitle;
            $clientdet1['firstname'] = $client->firstname;
            $clientdet1['lastnametitle'] = $client->lastnametitle;
            $clientdet1['lastname'] = $client->lastname;
            $clientdet1['email'] = $client->email;
            $clientdet1['Mobile_number'] = $client->Mobile_number;
        }
        return view('admin/fixappoinment')->with('appoinmentlist',$appoinmentlist)->with('hostlist', $hostlist)->with('doctors', $doctors)->with('apptimings', $apptimings)->with('clientdet',$clientdet1)->with('clientid',$clientid)->with('purpose_nxt_app',$purpose_nxt_app);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $date1 = str_replace('/', '-', $request->appdate);
        $appdate = date('Y-m-d', strtotime($date1));
        $appointmentdet = \session()->get('tempapp');
        //print_r($appointmentdet);exit;

//        $availability = DB::table('appoinments')->where('doctorid',$request->Doctors)->where('appoinment_time',$request->apptime)->where('appoinmentdate',$appdate)->count();
//        if($availability <=0) {
            $this->validate($request, [
                'Patient' => 'required|max:255',
                'doctors' => 'required|max:255',
                'appdate' => 'required|max:255',
                'branchcode' => 'required|max:255',
                /*'apptime' => 'required|max:10',*/
                'Host' => 'required'
            ]);

            $appoinments1 = new FixAppoinment;
            $appoinments = $appoinments1::find($id);

            $appoinments->patientid = $request->Patient;
            $appoinments->doctorid = $request->doctors;
            $appoinments->appoinmentdate = $appdate;
            $appoinments->branchcode = $request->branchcode;
            $appoinments->clientnote = $appointmentdet['appoint'];
            $appoinments->appointment_start = $appointmentdet['start'];
            $appoinments->appointment_end = $appointmentdet['end'];

            $appoinments->host_name = $request->Host;
            $appoinments->created_by = Auth::user()->id;
            $appoinments->updated_at = date("Y-m-d H:i:s");
            $appoinments->created_at = date("Y-m-d H:i:s");
            $appoinments->save();

        //Add appointment status
        $appstatus = new AppointmentStatusModel();
        $appstatus->appointment_id = $id;
        $appstatus->appointment_status = 'open';
        $appstatus->created_by = Auth::user()->id;
        $appstatus->updated_at = date("Y-m-d H:i:s");
        $appstatus->created_at = date("Y-m-d H:i:s");
        $appstatus->save();

            $request->session()->flash('alert-success', 'Appointment updated successfully!');
            return redirect()->route('appoinmentlist');
//        }
//        else{
//            $request->session()->flash('alert-success', 'This appoinment already fixed. Kindly re schedule the appoinment!');
//            return redirect()->action('AppoinmentController@index');
//        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function updatestatus(Request $request){

        $AppointmentID = $request['appid'];
        $AppointmentStatus = $request['appointmentstatus'];
        $Reason = $request['reason'];

        $appointment = new AppointmentStatusModel();

        $appointment->appointment_id = $AppointmentID;
        $appointment->appointment_status = $AppointmentStatus;
        $appointment->status_reason = $Reason;
        $appointment->created_by = Auth::User()->id;
        $appres = $appointment->save();

        if($appres){
            if($AppointmentStatus == "postponed"){
                $request->session()->flash('alert-success', 'Appointment updated successfully. Kindly reschedule the appointment.');
                return $this->show($AppointmentID);
            }else{
                $request->session()->flash('alert-success', 'Appointment cancelled successfully.');
                return redirect()->route('appoinmentlist');
            }

        }
        else{
            $request->session()->flash('alert-danger', 'Problem while updating this appointment. Kindly try again!');
            return redirect()->route('appoinmentlist');
        }


    }

    /**
     * update the unwanted rows in update as deleted
     */
    public function deleteappoinments(Request $request)
    {
        foreach($request->checkrow as $rowid) {
        $delappoinment = DB::table('appoinments')->where('id',$rowid)->update(['delet'=>1]);
    }
        $request->session()->flash('alert-success', 'Appointments deleted successfully!');
        return redirect()->route('appoinmentlist');
    }
}
