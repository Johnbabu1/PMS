<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use Illuminate\Support\Facades\Auth;
use DB;
use Validator, Input, Redirect, Url;


class usrlistingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
//
        //
        try {
            if (Auth::Check()) {
                if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin' || Auth::User()->Role == 'Host') {

                    $userlist = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->join('branches', 'branches.branchcode','=','registration_details.branchcode')->select('registration_details.*', 'users.*','branches.branchname')->where('users.Role', '=', "Client")->where('users.delet', '=', "0")->orderBy('users.created', 'desc');/*->take(20)*/
                    if((isset($request->clientid) && $request->clientid != '') OR (isset($request->clientname) && $request->clientname != '')){
                        $userlist = $userlist->where('users.id','=',$request->clientid)->orWhere('users.Mobile_number', 'like', '%' . $request->clientname . '%')->orWhere('registration_details.firstname',  'like', '%' . $request->clientname . '%');

                    }
                    $userlist = $userlist->get();
                    return view('admin/userlisting')->with('userlist', $userlist);
                } else {
                    return view('myaccount');
                }
            } else {
                return view('auth/login');
            }
        }
        catch(\Exception $e){
            \session()->flash('alert-success', 'Something went wrong while Getting information. Kindly contact administrator.');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $validate = Validator::make($request->all(), [
            'nametitle' => 'required|max:255',
            'firstname' => 'required|max:255',
            'lastnametitle' => 'required|max:255',
            'lastname' => 'required|max:255',
            'dob' => 'required|max:255',
            'Mobile_number' => 'required|max:14|min:7',
            'email' => 'required|email|max:255',
            'user_group' => 'required',
            'occupation' => 'required'
        ]);

        if ($validate->fails()) {

            //$url = URL::route('StaffController@index', array('#docothers'));
            return redirect('editstaff/'.$id.'/edit')
                ->withErrors($validate)
                ->withInput();
        }

        $date1 = str_replace('/', '-', $request->dob);
        $appdate = date('Y-m-d', strtotime($date1));
        if(Auth::Check()) {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'Doctor' || Auth::User()->Role == 'super_admin') {

                $userdet = User::find($id);
                $userdet->Mobile_number = $request->Mobile_number;
                $userdet->email = $request->email;
                $userdet->Role  = $request->user_group;
                $userdet->save();

                $reguserdet = registration::find($userdet->registerid);
                /*$reguserdet->nametitle = $request->nametitle;
                $reguserdet->firstname = $request->firstname;
                $reguserdet->lastnametitle = $request->lastnametitle;
                $reguserdet->lastname = $request->lastname;
                $reguserdet->branchcode = $request->branchcode;*/
                $reguserdet->sourceofreference = $request->sourceofreference;
                $reguserdet->referredby = $request->referredby;

                $reguserdet->designation = $request->occupation;
                /*$reguserdet->dob = $appdate;*/
                $reguserdet->save();

                $request->session()->flash('alert-success', 'Employee Details successfully updated!');
                return redirect()->action('StaffController@index');
            } else {
                return redirect('myaccount');
            }
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function deleteuser(Request $request)
    {
        foreach($request->userrow as $rowid) {
            //$delappoinment = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.id',$rowid)->update(['users.delet'=>1,'users.updated_at'=>date('Y-m-d'),'registration_details.delet'=>1]);
            $delappoinment = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.id',$rowid)->delete();
        }
        $request->session()->flash('alert-success', 'Users deleted successfully!');
        return redirect()->action('usrlistingController@index');
    }

}
