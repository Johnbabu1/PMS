<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\registration;
use App\User;
use App\Myaccount;
use Hash;
use Carbon\Carbon;
use Mail;
use Validator;
use Session;
use DB;

class RegistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $registrations = registration::all();
        //return view ('testdata.registrationdetails')->with('details',$registrations);
        //return 'we going to register some details';
        $countries = DB::table("countries")->lists("name","id");
        $states = DB::table("states")->where('country_id','101')->lists("name","id");
        $cities = DB::table("cities")->where('state_id','35')->lists("name", "id");
        return view('registration', compact('countries'))->with('states', $states)->with('cities', $cities);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function validator(array $data)
    {
        return Validator::make($data, [

            'nametitle' => 'required|max:255',
            'firstname' => 'required|max:255',
            'lastnametitle' => 'required|max:255',
            'lastname' => 'required|max:255',
            'Mobile_number' => 'required|max:10',
            'email' => 'required|email|max:255',
        ]);
    }
    public function create()
    {
        //
        //Store registration details in datatable
        //dd($request);


        //Sending Email
//        Mail::send('emails.reminder', ['name' => $request->firstname], function ($m) use ($request) {
//            $m->from('hello@app.com', 'Your Application');
//
//            $m->to($request->email, $request->firstname)->subject('Your Reminder!');
//        });
//        Mail::send('emails.registration',['name' => $request->firstname,'user_name' => $request->firstname, 'Password' => $request->firstname], function($m) use ($request){
//            $m->to($request->email, $request->firstname)->subject('Evidentdental Registration Completed');
//        });


        return view('myaccount');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $userreg = new User;
        $user = User::where('email', '=', $request->email)->first();
        if ($user === null) {

            $usercnt = DB::table('users')->join('registration_details','registration_details.id', '=', 'users.registerid')->where('users.created', Carbon::today()->format('Y-m-d'))->where('registration_details.branchcode',$request['branchcode'])->count();
            $usercnt = $usercnt + 1;

            $f2d = sprintf("%02d",$usercnt);
            $brcode = sprintf("%02d",$request['branchcode']);

            $data = $request['firstname'];
            $findme   = '.';

            $pos = strpos($data, $findme);
            $whatIWant = str_replace(' ', '', $data);
            if($pos < 4)
            {
                $strcnt = substr_count($whatIWant , ".");
                for($i=0;$i<$strcnt;$i++)
                {
                    $whatIWant = substr($whatIWant , strpos($whatIWant , ".") + 1);
                }
                //$whatIWant = substr($data, strpos($data, ".") + 1);
            }

            $nme = strtoupper(substr($whatIWant, 0,2));
            $dt = date('dmy');

            $usernamedet = $f2d.$brcode.$nme.$dt;

            // user doesn't exist
            //$dt = date('Y-m-d', strtotime($request->dob));
            $registration = new registration;
            $registration->nametitle = $request->nametitle;
            $registration->firstname = $request->firstname;
            $registration->lastnametitle = $request->lastnametitle;
            $registration->lastname = $request->lastname;
            $registration->address_line_1 = ucwords($request['address_line_1']);
            $registration->address_line_2 = ucwords($request['address_line_2']);
            $registration->country = $request['country'];
            $registration->state= $request['state'];
            $registration->city = $request['city'];
            $registration->pincode = $request['pincode'];
            $registration->branchcode = $request['branchcode'];
            //$registration->surname = $request->surname;
            //$registration->dob = $dt;
            /*$registration->sourceofreference = $request->sourceofreference;
            $registration->referredby = $request->referredby;*/
            $registration->save();
            //Users table insertion

            //$data['username'] = $usernamedet;
            $request->username = $usernamedet;
            $userreg->name = $usernamedet;
            //$data['email'] = $userreg->email = $request->email;
            $userreg->email = $request->email;
            $userreg->password = bcrypt($request->password);
            $userreg->Mobile_number = $request->Mobile_number;
            $userreg->registerid = $registration->id;
            $userreg->Role = 'Client';
            $userreg->remember_token = $request->_token;
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: pa.vel@evidentdental.in";
            $message = "<p>You have successfully Registered with Evidentdental.in</p>";
            $message .= "<p>&nbsp;&nbsp;</p>";
            $message .= "<p>Your UserName: $usernamedet</p>";
            $message .= "<p>Your Password:$request->password</p>";

            $message .= "You can login using this credentials now - <a href='http://evidentdental.in/vault/public/'>click here</a>";
            if ($userreg->save()) {
                /*Mail::send('emails.registration',['data'=>$data],function($mail) use ($data){
                    $mail->to($data['email'],$data['name'])->from('johnbabu19@gmail.com')->subject('Welcome');
                } );*/
                //mail($request->email, 'Registration Successfully', $message, $headers);
                Mail::send('emails.quickreg', ['data' => $request, 'username' => $usernamedet], function ($mail) use ($request) {
                    $mail->to($request->email, $request->name)->from('info@evidentdental.in')->subject('Welcome');
                });
            }
            Session::flush();
            $request->session()->flash('alert-success', 'User Details Registered successfully. Kindly check your email for funther details.');
            return redirect('registration');
        }else{
            Session::flush();
            $request->session()->flash('alert-danger', 'Email alredy exist.');
            return redirect('registration');
        }


    }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        return redirect('registration');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
