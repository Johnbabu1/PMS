<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\doctorcomm;

class doctorcommunication extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Block to store doctor communication details
        $this->validate($request, [
            'contactnumber' => 'required|max:14',
            'priority' => 'required',
        ]);
        if(strlen($request->voice_call) == 0) $voicecall = 0;else $voicecall = 1;
        if(strlen($request->sms) == 0) $sms = 0;else $sms = 1;
        if(strlen($request->whatsapp) == 0) $whatsapp = 0;else $whatsapp = 1;

        $communication = new doctorcomm();
        $communication->doctor_id = $request->doctor_id;
        $communication->contactnumber = $request->contactnumber;
        $communication->voice_call = $voicecall;
        $communication->sms = $sms;
        $communication->whatsapp = $whatsapp;
        $communication->priority = $request->priority;
        $communication->save();

        $request->session()->flash('alert-success', 'Contact detail added successfully');
        return redirect('myaccount');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
