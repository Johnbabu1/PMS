<?php

namespace App\Http\Controllers;

use App\Sourceofreference_model;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use Illuminate\Support\Facades\Auth;
use App\doctorcomm;
use App\Remainder_model;
use DB;

class RemainderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index(Request $request)
    {
        //
        if(Auth::Check())
        {

            if(Auth::User()->Role == 'super_admin'){
                $remainderlist = DB::table('remainders')->select(DB::raw("remainders.*, (SELECT CONCAT(registration_details.nametitle,'',registration_details.firstname) FROM registration_details INNER JOIN users ON users.registerid = registration_details.id WHERE users.id = remainders.created_by) AS username, (SELECT CONCAT(registration_details.nametitle,'',registration_details.firstname) FROM registration_details INNER JOIN users ON users.registerid = registration_details.id WHERE users.id = remainders.user_id) AS remainderto"))->where('remainders.status','active');
                if(isset($request->clientid) && $request->clientid != '' && $request->clientname != ''){
                    $remainderlist = $remainderlist->where('remainders.user_id','=',$request->clientid);
                }
                if(isset($request->stappdate) && $request->stappdate != '' ){
                    $date1 = str_replace('/', '-', $request->stappdate);
                    $stappdate = date('Y-m-d', strtotime($date1));
                    $date1 = str_replace('/', '-', $request->endappdate);
                    $endappdate = date('Y-m-d', strtotime($date1));
                    if($request->stappdate != '' && isset($request->endappdate) && $request->endappdate != '' ){
                        $remainderlist = $remainderlist->whereRaw("remainders.remainder_date BETWEEN '$stappdate' AND '$endappdate' ");
                    }elseif($request->stappdate != '' && $request->endappdate == ''){
                        $remainderlist = $remainderlist->whereRaw("remainders.remainder_date = '$stappdate'");
                    }
                }

                $remainderlist = $remainderlist->limit('2000')->orderBy('remainders.remainder_date','DESC')->get();
            }else{
                $remainderlist = DB::table('remainders')->select(DB::raw("remainders.*, (SELECT CONCAT(registration_details.nametitle,'',registration_details.firstname) FROM registration_details INNER JOIN users ON users.registerid = registration_details.id WHERE users.id = remainders.created_by) AS username"))->where('remainders.status','active')->where('remainders.user_id', AUTH::user()->id)->where('remainders.remainder_date', '>=', date('Y-m-d'));
                if(isset($request->clientid) && $request->clientid != '' && $request->clientname != ''){
                    $remainderlist = $remainderlist->where('remainders.user_id','=',$request->clientid);
                }
                if(isset($request->stappdate) && $request->stappdate != '' ){
                    $date1 = str_replace('/', '-', $request->stappdate);
                    $stappdate = date('Y-m-d', strtotime($date1));
                    $date1 = str_replace('/', '-', $request->endappdate);
                    $endappdate = date('Y-m-d', strtotime($date1));
                    if($request->stappdate != '' && isset($request->endappdate) && $request->endappdate != '' ){
                        $remainderlist = $remainderlist->whereRaw("remainders.remainder_date BETWEEN '$stappdate' AND '$endappdate' ");
                    }elseif($request->stappdate != '' && $request->endappdate == ''){
                        $remainderlist = $remainderlist->whereRaw("remainders.remainder_date = '$stappdate'");
                    }
                }
                $remainderlist = $remainderlist->get();
            }

            return view('remainders')->with('remainderlist', $remainderlist);
        }
        else{
            return redirect('myaccount');
        }
        //return view('myaccount');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {

                return view('addremainder');
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('myaccount');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Block to store doctor communication details
        if(Auth::Check()) {

            $this->validate($request, [
                'remainder_title' => 'required',
                'remainder_to' => 'required',
                'remainder_description' => 'required',
                'remainder_date' => 'required'
            ]);

            $date1 = str_replace('/', '-', $request->remainder_date);
            $appdate = date('Y-m-d', strtotime($date1));
            $remainder = new Remainder_model();
            $remainder->remainder_title = $request->remainder_title;
            $remainder->user_id = $request->user_id;
            $remainder->remainder_description = $request->remainder_description;
            $remainder->remainder_date = $appdate;
            $remainder->remainder_time = $request->remainder_time.' '.$request->meridian;
            $remainder->created_by = Auth::user()->id;
            $remainder->save();

            \session()->flash('alert-success', 'Remainder Successfully Created.');
            return redirect('remainders');
        }
        else{
            return view('myaccount');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        if(Auth::Check())
        {
            $remainderlist = DB::table('remainders')->select(DB::raw("remainders.*, (SELECT CONCAT(nametitle , ' ',firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE remainders.user_id = users.id) AS username"))->where('remainders.status','active')->where('remainders.created_by', AUTH::user()->id)->where('remainders.remainder_date', '>=', date('Y-m-d'))->get();
            return view('sentremainders')->with('remainderlist', $remainderlist);
        }
        else{
            return redirect('myaccount');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        if(Auth::Check())
        {
            $remainderlist = DB::table('remainders')->select(DB::raw("remainders.*, CONCAT(registration_details.nametitle,'',registration_details.firstname) AS username"))->join('users', 'users.registerid','=','remainders.user_id')->join('registration_details','registration_details.id','=','users.registerid')->where('remainders.status','active')->where('remainders.id', $id)->get();
            return view('editremainder')->with('remainderlist', $remainderlist);
        }
        else{
            return redirect('myaccount');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        if(Auth::Check()) {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
                $this->validate($request, [
                    'remainder_title' => 'required',
                    'remainder_to' => 'required',
                    'remainder_description' => 'required',
                    'remainder_date' => 'required'
                ]);

                $date1 = str_replace('/', '-', $request->remainder_date);
                $appdate = date('Y-m-d', strtotime($date1));

                $remainder = new Remainder_model();
                $updremainder = $remainder::find($id);
                $updremainder->remainder_title = $request->remainder_title;
                $updremainder->user_id = $request->user_id;
                $updremainder->remainder_description = $request->remainder_description;
                $updremainder->remainder_date = $appdate;
                $updremainder->remainder_time = $request->remainder_time.' '.$request->meridian;
                $updremainder->updated_by = Auth::user()->id;
                $updremainder->save();

                $request->session()->flash('alert-success', 'Remainder Updated Successfully.');
                return redirect('remainders');
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('myaccount');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if(Auth::Check()) {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
                $procedures = new proceduredetails_model();
                $updprocedure = $procedures::find($id);
                $updprocedure->hide = 'yes';
                $updprocedure->updated_by = Auth::user()->id;
                $updprocedure->save();
                \session()->flash('alert-success', 'Procedure deleted successfully.');
                return redirect('procedures');
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('myaccount');
        }

    }
}
