<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use App\sourceofreference_model;
use Illuminate\Support\Facades\Auth;
use DB;
use Carbon\Carbon;
use Mail;
use App\appoinment_timemodel;
use Validator, Input, Redirect, Url;

class ClientViewModel{
    public $ClientName;
    public $DoctorName;
    public $Branch;
    public $HostName;
    public $Status;
    public $DateTime;
    public $TotalPayment;
    public $Payment;
    public $PaymentMode;
    public $BalancePayment;
    public $ClientLoginTime;
    public $ProcedureStartTime;
    public $ProcedureEndTime;
    public $ChiefComplaint;
    public $Diagnosis;
    public $OtherFindings;
    public $TreatmentDone;
    public $NextAppointmentPurpose;
    public $ClientNote;
}

class ClientController extends Controller
{


        /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //


    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        if(Auth::Check()) {

            if (Auth::User()->Role == 'Client') {
                if(Auth::User()->id == $id){
                    $accountdetails = new User;
                    $userdetails = new registration;
                    $allvalue = $userdetails::find(Auth::user()->registerid);
                    $account = $accountdetails::find(Auth::user()->id);
                    return view('client/dashboard')->with('account', $account)->with('allvalue', $allvalue);
                }else{
                      return redirect('auth/logout');
                }
            } else {
                return redirect('auth/logout');
            }
        }
        else {
            return redirect('auth/logout');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        if(Auth::Check()) {
            if (Auth::User()->Role == 'Client') {
                if (Auth::User()->id == $id) {
                    $accountdetails = new User;
                    $userdetails = new registration;
                    $allvalue = $userdetails::find(Auth::user()->registerid);
                    $account = $accountdetails::find(Auth::user()->id);
                    $countries = DB::table("countries")->lists("name","id");
                    $states = DB::table("states")->where('country_id','101')->lists("name","id");
                    $cities = DB::table("cities")->where('state_id','35')->lists("name", "id");
                    $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
                    return view('client/myaccount')->with('account', $account)->with('allvalue', $allvalue)->with('sourcelist',$sourcelist)->with('countries', $countries)->with('states', $states)->with('cities', $cities);
                }
                else{
                    return redirect('auth/logout');
                }
            }
            else{
                return redirect('auth/logout');
            }
        }else {
            return redirect('auth/logout');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    //Update Staff details as deleted
    public function deletebulkstaff(Request $request)
    {
        foreach($request->userrow as $rowid) {
            //$delappoinment = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.id',$rowid)->update(['users.delet'=>1,'users.updated_at'=>date('Y-m-d'),'registration_details.delet'=>1]);
            $delappoinment = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('users.id',$rowid)->delete();
        }
        $request->session()->flash('alert-success', 'Staff deleted successfully!');
        return redirect()->action('StaffController@index');
    }

    //Show appointments
    public function myappointments(Request $request){

        if (Auth::Check())
        {
            if (Auth::User()->Role == 'Client' || Auth::User()->Role == 'super_admin')
            {
                $accountdetails = new User;
                $userdetails = new registration;
                $allvalue = $userdetails::find(Auth::user()->registerid);
                $account = $accountdetails::find(Auth::user()->id);
                $userlist = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*', 'users.*')->where('users.Role', '=', "Doctor")->orWhere('users.Role', '=', "Staff")->get();

                //        $appoinmentlist = DB::table('appoinments')->get();
                $appoinment = DB::table('appoinments')->select(DB::raw("(SELECT CONCAT(nametitle,'',firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) AS patientname"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT CONCAT(nametitle,'',firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.host_name = users.id) As hostname"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT Mobile_number FROM users WHERE appoinments.patientid = users.id) As mobile"));
                $appoinment = $appoinment->addSelect(DB::raw("appoinments.*"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT GROUP_CONCAT(inspection_procedure.procedure_name) FROM inspection_procedure LEFT JOIN inspection_details ON inspection_details.id = inspection_procedure.inspection_id WHERE inspection_details.appoinment_id = appoinments.id) as treatmentdone"));
                /*$appoinment = $appoinment->addSelect(DB::raw("(SELECT timings FROM appoinment_time WHERE appoinment_time.id = appoinments.appoinment_time) AS appoinment_time"));*/
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT branchname FROM branches WHERE branches.id = appoinments.branchcode) AS branchcode"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT appointment_status.status_reason FROM appointment_status WHERE appointment_status.appointment_id = appoinments.id ORDER BY appointment_status.created_at DESC LIMIT 1) As reason"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.appointment_id = appoinments.id ORDER BY appointment_status.created_at DESC LIMIT 1) As status"));
                $appoinment4 = $appoinment->addSelect(DB::raw("appoinments.id"))->where('delet', "0")->where('appoinments.patientid', Auth::User()->id);
                if(isset($request->stappdate) && $request->stappdate != '' ){
                    $date1 = str_replace('/', '-', $request->stappdate);
                    $stappdate = date('Y-m-d', strtotime($date1));
                    $date1 = str_replace('/', '-', $request->endappdate);
                    $endappdate = date('Y-m-d', strtotime($date1));
                    if($request->stappdate != '' && isset($request->endappdate) && $request->endappdate != '' )
                    {
                        $appoinment4 = $appoinment4->whereRaw("appoinments.appoinmentdate BETWEEN '$stappdate' AND '$endappdate' ");
                    }
                    elseif($request->stappdate != '' && $request->endappdate == ''){
                        $appoinment4 = $appoinment4->whereRaw("appoinments.appoinmentdate = '$stappdate'");
                    }
                }

                //$appoinmentlist = $appoinment4->orderBy('appoinments.appoinmentdate', 'asc')->orderBy('appoinments.appointment_start','DESC')->orderBy('branchcode','DESC')->get();
                $appoinmentlist = $appoinment4->orderBy('appoinments.appointment_start','DESC')->get();
                //      $appoinmentlist = $appoinment->addSelect(DB::raw())->get();,

                return view('client/appoinmentlist')->with('allvalue', $allvalue)->with('account', $account)->with('appoinmentlist', $appoinmentlist);

            } else {
                return redirect('auth/logout');
            }
        }
        else {
            return redirect('auth/logout');
        }
    }
}
