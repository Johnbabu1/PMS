<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use Illuminate\Support\Facades\Auth;
use DB;
use Carbon\Carbon;
use Mail;

class QuickregistrationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin' || Auth::User()->Role == 'Host')
            {
                return view('admin/quickregistration');
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('auth/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $this->validate($request, [
            'nametitle' => 'required|max:255',
            'firstname' => 'required|max:255',
            'lastnametitle' => 'required|max:255',
            'lastname' => 'required|max:255',
            'gender' => 'required',
            'Mobile_number' => 'required|max:14|min:6',
            'branchcode' => 'required',
        ]);

        $usercnt = DB::table('users')->join('registration_details','registration_details.id', '=', 'users.registerid')->where('users.created', Carbon::today()->format('Y-m-d'))->where('registration_details.branchcode',$request['branchcode'])->count();
        $usercnt = $usercnt + 1;
        $f2d = sprintf("%02d",$usercnt);
        $brcode = sprintf("%02d",$request['branchcode']);
        $data = $request['firstname'];
        $findme   = '.';

        $pos = strpos($data, $findme);
        $whatIWant = str_replace(' ', '', $data);
        if($pos < 4)
        {
            $strcnt = substr_count($whatIWant , ".");
            for($i=0;$i<$strcnt;$i++)
            {
                $whatIWant = substr($whatIWant , strpos($whatIWant , ".") + 1);
            }
            //$whatIWant = substr($data, strpos($data, ".") + 1);
        }

        $nme = strtoupper(substr($whatIWant, 0,2));
        //$nme = strtoupper(substr($request['firstname'], 0,2));
        $dt = date('dmy');
        $username = $f2d.$brcode.$nme.$dt;

        /*$sms = 'Dear '.$request['nametitle'].'. '.$request['firstname'];
        $sms .= "Welcome to Evident. Please call toll free 39592005 for appointments and queries. We'll call you back. For any complaints sms Dr.Karthick @ 9841698866";

        $url = "http://smsserver9.creativepoint.in/api.php?";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'username=evident&password=360196&to='.$request['Mobile_number'].'&from=EVIDNT&message='.$sms.'');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);

        echo $result;
        if(curl_error($ch))
        {
            echo 'error:' . curl_error($ch);
        }
        exit;*/


        $registration = registration::create([
            'nametitle' => $request['nametitle'],
            'firstname' => ucwords($request['firstname']),
            'lastnametitle' => $request['lastnametitle'],
            'lastname' => ucwords($request['lastname']),
            'branchcode' => $request['branchcode'],
            'created_by' => Auth::user()->id
        ]);
//
        User::create([
            'name' => $username,
            'password' => bcrypt($request['firstname']),
            'Mobile_number' => $request['Mobile_number'],
            'registerid' => $registration->id,
            'Role'     => 'Client',
            'created'  => date('Y-m-d'),
            'remember_token' => $request['_token'],
            'created_by' => Auth::user()->id
        ]);
//
        $request->nametitle = $request['nametitle'];
        $request->username = $username;
        $request->password = $request['firstname'];
        $request->email = $request['email'];
        $request->firstname = $request['firstname'];   
//       if ($userreg->save()) {
//        Mail::send('emails.registration',['data'=>$request, 'userame' =>$username ],function($mail) use ($request){
//            $mail->to($request['email'],$request['name'])->from(Auth::user()->email)->subject('Welcome');
//        } );

        //SMS body starts here
        $sms = 'Dear '.$request['nametitle'].'. '.ucwords($request['firstname'].',');
        $sms .= "Welcome to Evident. Please call toll free 39592005 for appointments and queries. We'll call you back. For any complaints sms Dr.Karthick @ 9841698866";
        //$sms .= 'Kindly check your email to know your login details.';

        //SMS body ends here

       /* $url = "http://smsserver9.creativepoint.in/api.php?";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POSTFIELDS, 'username=evident&password=360196&to='.$request['Mobile_number'].'&from=EVIDNT&message='.$sms.'');
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $result = curl_exec($ch);*/

        Mail::send('emails.quickreg', ['data' => $request, 'username' => $username], function ($mail) use ($request) {
            $mail->to($request->email, $request->name)->from('info@evidentdental.in')->subject('Welcome');
        });
        /*if( count(Mail::failures()) > 0 ) {

            echo "There was one or more failures. They were: <br />";

            foreach(Mail::failures as $email_address) {
                echo " - $email_address <br />";
            }

        }*/

        $request->session()->flash('alert-success', 'User was successfully registered!');
        return redirect()->action('QuickregistrationController@index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        try {

            $countries = DB::table("countries")->lists("name", "id");
            $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
            $states = array();
            $cities = array();

            $edituserdet = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*', 'users.*')->where('users.id', '=', $id)->where('users.delet', '=', "0")->take(1)->get();
            foreach ($edituserdet as $item) {
                $states = DB::table("states")->where('country_id', $item->country)->lists("name", "id");
                $cities = DB::table("cities")->where('state_id', $item->state)->lists("name", "id");
            }

            //return $edituserdet;
            return view('edituser', compact('countries'))->with('edituserdet', $edituserdet)->with('states', $states)->with('cities', $cities)->with('sourcelist', $sourcelist);
        }
        catch(\Exception $e){
            \session()->flash('alert-success', 'Something went wrong while Getting information. Kindly contact administrator.');
            return redirect('userlisting');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
