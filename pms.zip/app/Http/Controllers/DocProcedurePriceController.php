<?php

namespace App\Http\Controllers;

use App\Sourceofreference_model;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use Illuminate\Support\Facades\Auth;
use App\doctorcomm;
use App\DoctorprocedurePrice;
use ValidatesRequests;
use DB;


class DocProcedurePriceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {

                $procedure = new DoctorprocedurePrice();
                $procedurelist = DB::table('doctor_procedure_price')->join('users','users.id','=','doctor_procedure_price.dotor_id')->join('registration_details','users.registerid','=','registration_details.id')->select('doctor_procedure_price.id','doctor_procedure_price.procedure_name','doctor_procedure_price.procedure_price','registration_details.nametitle','registration_details.firstname')->where('doctor_procedure_price.hide','no')->get();

                return view('admin/doctorprocedureprice')->with('docprocedurelist', $procedurelist);
            }
            elseif(Auth::User()->Role = 'Doctor'){

                $procedurelist = DB::select(DB::raw("SELECT id,procedure_name, (SELECT procedure_price FROM doctor_procedure_price WHERE procedure_details.procedure_name = doctor_procedure_price.procedure_name AND doctor_procedure_price.hide = 'no' AND  doctor_procedure_price.dotor_id = '".Auth::User()->id."' LIMIT 0,1) AS procedure_price FROM procedure_details"));
                return view('doctor/procedureprice')->with('procedurelist',$procedurelist);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('myaccount');
        }
        //return view('myaccount');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {

                $doctors = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('Role','Doctor')->lists(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'users.id');
                $procedures = DB::table('procedure_details')->where('hide','no')->lists('procedure_name','procedure_name');
                return view('admin/adddoctorprocedureprice')->with('doctors',$doctors)->with('procedures', $procedures);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('myaccount');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //Block to store doctor communication details

        $this->validate($request, [
            'doctors' => 'required|max:255',
            'procedurename' => 'required|max:255',
            'procedureprice' => 'required|max:255',
        ]);

        $procedure = new DoctorprocedurePrice();
        $procedure->dotor_id = $request->doctors;
        $procedure->procedure_name = $request->procedurename;
        $procedure->procedure_price = $request->procedureprice;
        $procedure->price_from = date('Y-m-d h:i:s');
        $procedure->hide = 'no';
        $procedure->created_by = Auth::User()->id;
        $res = $procedure->save();
        if($res){
            $request->session()->flash('alert-success', 'Procedure Created Successfully!');
            return redirect('doctorprocedureprice');
        }
        else{
            $request->session()->flash('alert-danger', 'Error while Creating Procedure!');
            return redirect('doctorprocedureprice');
        }
     }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {

                $doctors = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('Role','Doctor')->lists(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'users.id');
                $procedures = DB::table('procedure_details')->where('hide','no')->lists('procedure_name','procedure_name');
                $procedure = new DoctorprocedurePrice();
                $proceduredet = $procedure::find($id);
                return view('admin/editdoctorprocedureprice')->with('doctors',$doctors)->with('procedures', $procedures)->with('proceduredet',$proceduredet);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('myaccount');
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $procedure = new DoctorprocedurePrice();
        $procedure1 = $procedure::find($id);
        $procedure1->price_to = date('Y-m-d H:i:s');
        $procedure1->save();

        $procedure = new DoctorprocedurePrice();
        $procedure->dotor_id = $request->doctors;
        $procedure->procedure_name = $request->procedurename;
        $procedure->procedure_price = $request->procedureprice;
        $procedure->price_from = date('Y-m-d h:i:s');
        $procedure->hide = 'no';
        $procedure->created_by = Auth::User()->id;
        $res = $procedure->save();

        if($res){
            $request->session()->flash('alert-success', 'Procedure Updated Successfully!');
            return redirect('doctorprocedureprice');
        }
        else{
            $request->session()->flash('alert-danger', 'Error while Updating Procedure!');
            return redirect('doctorprocedureprice');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //

    }
}
