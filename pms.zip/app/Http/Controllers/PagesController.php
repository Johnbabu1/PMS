<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\registration;
use DB;
use Illuminate\Http\Request;
use App\Http\Requests;
use Carbon\Carbon;
use Mail;
use Illuminate\Support\Facades\Hash;

class PagesController extends Controller
{
    public function getIndex(){
        if(Auth::Check()) {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin')
            {
                return redirect()->action('PagesController@appoinmentlist');
            }
            elseif(Auth::User()->Role == 'Doctor') {
                return redirect()->action('PagesController@doctorappoinmentlist');
            }
            elseif(Auth::User()->Role == 'Staff')
            {
                return "<h2>Staff Pages Yet to done..!!<br><a href='auth/logout'><h4>logout</h4></a></h2>";
            }
            elseif(Auth::User()->Role == 'Client')
            {
                return redirect()->action("ClientController@show", ['id' => Auth::User()->id]);
            }
            elseif(Auth::User()->Role == 'Host')
            {
                return redirect('inspection_details');
            }
            else{
                return "<h2>You are not authentiate user..!! Check login..!!</h2><br><a href='auth/logout'><h4>logout</h4></a>";
            }
    }
        else{
            return view('auth/login');
        }
    }
    public function getRegister()
    {
        if(Auth::Check()) {
            return redirect()->action('MyaccountController@index');
        }else {
            return view('registration');
        }
    }
    public function getReg()
    {
        if(Auth::Check()) {
            return redirect()->action('MyaccountController@index');
        }else {
            return view('auth/register');
        }
    }
    /*Proper redirection after successfull login*/
    public function redirectacc()
    {
        if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin')
        {
            return redirect()->action('usrlistingController@index');
        }
        elseif(Auth::User()->Role == 'Doctor') {
            return redirect()->action('pagesController@doctorappoinmentlist');
        }

    }
    public function getMyaccount()
    {
        return view('myaccount');
    }
    public function addStaff()
    {
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin')
            {
                $sourcelist = DB::table("sourceofreference")->where('hide','no')->lists("sourceofreference","id");
                $userlist = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*','users.*')->where('users.Role', '=', "Doctor")->orWhere('users.Role', '=', "Staff")->get();
                return view('admin/addStaff')->with('sourcelist', $sourcelist);
            }
            else{
                return redirect('myaccount');
            }
        }
        else{
            return redirect('auth/login');
        }
    }
    public function appoinmentlist(Request $request)
    {
        if (Auth::Check())
        {
            if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin' || Auth::User()->Role == 'Host')
            {
                $userlist = DB::table('registration_details')->join('users', 'registration_details.id', '=', 'users.registerid')->select('registration_details.*', 'users.*')->where('users.Role', '=', "Doctor")->orWhere('users.Role', '=', "Staff")->get();

                //        $appoinmentlist = DB::table('appoinments')->get();
                $appoinment = DB::table('appoinments')->select(DB::raw("(SELECT CONCAT(nametitle,'',firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) AS patientname"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT CONCAT(nametitle,'',firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.host_name = users.id) As hostname"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT Mobile_number FROM users WHERE appoinments.patientid = users.id) As mobile"));
                $appoinment = $appoinment->addSelect(DB::raw("appoinments.*"));
                $appoinment = $appoinment->addSelect(DB::raw("inspection_details.id as ins_id"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT appointment_status.status_reason FROM appointment_status WHERE appointment_status.appointment_id = appoinments.id ORDER BY appointment_status.created_at DESC LIMIT 1) As reason"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.appointment_id = appoinments.id ORDER BY appointment_status.created_at DESC LIMIT 1) As status"));
                /*$appoinment = $appoinment->addSelect(DB::raw("(SELECT timings FROM appoinment_time WHERE appoinment_time.id = appoinments.appoinment_time) AS appoinment_time"));*/
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT branchname FROM branches WHERE branches.id = appoinments.branchcode) AS branchcode"));
                $appoinment = $appoinment->join('inspection_details','inspection_details.appoinment_id','=','appoinments.id','left outer');
                $appoinment4 = $appoinment->where('appoinments.delet','0');
                //$appoinment4 = $appoinment;
                if(isset($request->clientid) && $request->clientid != ''){
                    $appoinment = $appoinment->where('appoinments.patientid','=',$request->clientid)->orderBy('appoinments.appoinmentdate','DESC');
                }
                if(isset($request->stappdate) && $request->stappdate != '' ){
                    $date1 = str_replace('/', '-', $request->stappdate);
                    $stappdate = date('Y-m-d', strtotime($date1));
                    $date1 = str_replace('/', '-', $request->endappdate);
                    $endappdate = date('Y-m-d', strtotime($date1));
                    if($request->stappdate != '' && isset($request->endappdate) && $request->endappdate != '' )
                    {
                        $appoinment4 = $appoinment4->whereRaw("appoinments.appoinmentdate BETWEEN '$stappdate' AND '$endappdate' ");
                    }
                    elseif($request->stappdate != '' && $request->endappdate == ''){
                        $appoinment4 = $appoinment4->whereRaw("appoinments.appoinmentdate = '$stappdate'");
                    }
                }
                else{
                    $appoinment4 = $appoinment4->whereRaw('Date(appoinments.appoinmentdate) = CURDATE()');
                }
                $appoinmentlist = $appoinment4->orderBy('appoinments.appoinmentdate', 'asc')->orderBy('appoinments.appointment_start','ASC')->orderBy('branchcode','DESC')->get();
                //      $appoinmentlist = $appoinment->addSelect(DB::raw())->get();,

                return view('admin/appoinmentlist')->with('appoinmentlist', $appoinmentlist);

            } else {
                return redirect('auth/login');
            }
        }
        else {
            return redirect('auth/login');
        }
    }
    /*Doctor individual appoinment list page*/
    public function doctorappoinmentlist(Request $request)
    {
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'Doctor')
            {

                $appoinment = DB::table('appoinments')->select(DB::raw("(SELECT CONCAT(nametitle,'',firstname,' ',lastname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) AS patientname"));
                $appoinment1 = $appoinment->addSelect(DB::raw("(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname"));
                $appoinment2 = $appoinment->addSelect(DB::raw("appoinments.*"));
                $appoinment3 = $appoinment->addSelect(DB::raw("(SELECT timings FROM appoinment_time WHERE appoinment_time.id = appoinments.appoinment_time) AS appoinment_time"));
                $appoinment3 = $appoinment->addSelect(DB::raw("(SELECT branchname FROM branches WHERE branches.id = appoinments.branchcode) AS branchcode"));
                $appoinment4 = $appoinment3->addSelect(DB::raw("appoinments.id"))->where('delet', "0")->where('appoinments.doctorid', Auth::user()->id)->orderBy('appoinments.appoinmentdate', 'desc');
                if(isset($request->stappdate) && $request->stappdate != '' ){
                    $date1 = str_replace('/', '-', $request->stappdate);
                    $stappdate = date('Y-m-d', strtotime($date1));
                    $date1 = str_replace('/', '-', $request->endappdate);
                    $endappdate = date('Y-m-d', strtotime($date1));
                    if($request->stappdate != '' && isset($request->endappdate) && $request->endappdate != '' )
                    {
                        $appoinment4 = $appoinment4->whereRaw("appoinments.appoinmentdate BETWEEN '$stappdate' AND '$endappdate' ");
                    }
                    elseif($request->stappdate != '' && $request->endappdate == ''){
                        $appoinment4 = $appoinment4->whereRaw("appoinments.appoinmentdate = '$stappdate'");
                    }
                }
                else{
                    $appoinment4 = $appoinment4->whereRaw("appoinments.appoinmentdate = CURDATE()");
                }
                //      $appoinmentlist = $appoinment->addSelect(DB::raw())->get();
                $appoinmentlist = $appoinment4->orderBy('appoinments.appoinmentdate', 'asc')->orderBy('appoinments.appointment_start','ASC')->orderBy('branchcode','DESC')->get();

                return view('doctor/doctorappoinmentlist')->with('appoinmentlist', $appoinmentlist);
            }
            elseif(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin' || Auth::User()->Role == 'Host')
            {
                return redirect('appoinmentlist');
            }
            else{
                return redirect('auth/logout');
            }
        }
        else {
            return redirect('auth/logout');
        }
    }

    //Function to show settings page
    function settings()
    {
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin')
            {
                return view('admin/settings');
            }
            else{
                return redirect('auth/logout');
            }
        }
        else {
            return redirect('auth/logout');
        }
    }

    function changepassword(){
        if(Auth::Check())
        {
            return view('changepassword');
        }else{
            return redirect('auth/logout');
        }
    }

    function resetpassword(Request $request){
        if(Auth::Check()){
            $accountdetails = new User;
            $usrdet = $accountdetails::find(Auth::User()->id);
            if (Hash::check($request->oldpassword, $usrdet->password)) {
                // The passwords match...
                $usrdet->password = Hash::make($request->newpassword);
                $usrdet->save();

                $request->session()->flash('alert-success', 'Password changed successfully!');
                return redirect('auth/logout');

            }
            else{
                $request->session()->flash('alert-danger', 'Password Not Matched');
                return redirect('changepassword');
            }
        }
        else{
            return redirect('auth/logout');
        }
    }

    function sample(){
        if(Auth::Check())
        {
            if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin')
            {
                $patientlist = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('Role','Client')->lists('registration_details.firstname','users.id');
                $doctors = DB::table('users')->join('registration_details','registration_details.id','=','users.registerid')->where('Role','Doctor')->lists(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'users.id');
                $apptimings = DB::table('appoinment_time')->lists('timings','id');
                return view('admin/samplefixappoinment')->with('patientlist',$patientlist)->with('doctors',$doctors)->with('apptimings', $apptimings);
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('auth/login');
        }
    }
}