<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\User;
use App\registration;
use Illuminate\Support\Facades\Auth;
use DB;
use Carbon\Carbon;
use Mail;
use App\Inspection_model;
use App\FixAppoinment;
use App\Inspectionprocedure_model;
use App\ClientPaymentInfo;

class InspectionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //
        if(Auth::Check())
        {
            if( Auth::User()->Role == 'Doctor' )
            {
                $inspection = DB::table('inspection_details')
                    ->Select('inspection_details.id','inspection_details.appoinment_id', 'inspection_details.chief_complaint','inspection_details.diagnosed_complaint', 'inspection_details.total_price', 'inspection_details.next_appoinment_id', 'appoinments.appoinmentdate', 'appoinments.appointment_desc','appoinments.appointment_start','appoinments.appointment_end')
                ->addSelect(DB::raw('(SELECT timings FROM appoinment_time WHERE appoinment_time.id = appoinments.appoinment_time) AS appoinment_time'))
                ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname'))
                ->addSelect(DB::raw('(SELECT branchname FROM branches WHERE branches.id = appoinments.branchcode) AS branchcode'))
                ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) As clientnme'))
                    ->addSelect(DB::raw('(SELECT balance_payment FROM client_payment_info WHERE client_payment_info.appointment_id = appoinments.id Order By client_payment_info.created_at DESC LIMIT 1 ) As balence_amt'))
                ->join('appoinments', 'appoinments.id', '=', 'inspection_details.appoinment_id');
                if(isset($request->clientid) && $request->clientid != ''){
                    $appqry = DB::table('appoinments')->select('*')->where('appoinments.patientid','=',$request->clientid)->where('doctorid', Auth::User()->id)->get();
                    //$appcnt = $appqry->count();
                    if($appqry > 0){
                        $inspection = $inspection->where('appoinments.patientid','=',$request->clientid);
                    }else{
                        $inspection = $inspection->where('appoinments.doctorid', Auth::User()->id)->where('appoinments.patientid','=',$request->clientid);
                    }

                }else{
                    $inspection = $inspection->where('appoinments.doctorid', Auth::User()->id);
                }

                if(isset($request->stappdate) && $request->stappdate != '' ){
                    $date1 = str_replace('/', '-', $request->stappdate);
                    $stappdate = date('Y-m-d', strtotime($date1));
                    $date1 = str_replace('/', '-', $request->endappdate);
                    $endappdate = date('Y-m-d', strtotime($date1));
                    if($request->stappdate != '' && isset($request->endappdate) && $request->endappdate != '' )
                    {
                        $inspection = $inspection->whereRaw("appoinments.appoinmentdate BETWEEN '$stappdate' AND '$endappdate' ");
                    }
                    elseif($request->stappdate != '' && $request->endappdate == ''){
                        $inspection = $inspection->whereRaw("appoinments.appoinmentdate = '$stappdate'");
                    }
                }
                elseif(!isset($request->clientid) || $request->clientid == ''){
                    $inspection = $inspection->whereRaw('Date(appoinments.appoinmentdate) = CURDATE()');
                }else{
                    //$inspection = $inspection->whereRaw('Date(appoinments.appoinmentdate) = CURDATE()');
                }
                $inspectionlist = $inspection->orderBy('appoinments.appoinmentdate','DESC')->get();
                return view('doctor/inspectionlist')->with('inspectionlist', $inspectionlist);
            }
            elseif(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin'){

                $inspection = DB::table('inspection_details')
                    ->Select('inspection_details.id','inspection_details.appoinment_id', 'inspection_details.chief_complaint','inspection_details.diagnosed_complaint','inspection_details.client_payment','inspection_details.total_price', 'inspection_details.balance_price', 'inspection_details.total_price', 'inspection_details.next_appoinment_id', 'appoinments.appoinmentdate',  'appoinments.appointment_desc','appoinments.appointment_start','appoinments.appointment_end')
                    ->addSelect(DB::raw('(SELECT timings FROM appoinment_time WHERE appoinment_time.id = appoinments.appoinment_time) AS appoinment_time'))
                    ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname'))
                    ->addSelect(DB::raw('(SELECT branchname FROM branches WHERE branches.id = appoinments.branchcode) AS branchcode'))
                    ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) As clientnme'))
                    ->addSelect(DB::raw('(SELECT balance_payment FROM client_payment_info WHERE client_payment_info.appointment_id = appoinments.id Order By client_payment_info.created_at DESC LIMIT 1 ) As balence_amt'))
                    ->join('appoinments', 'appoinments.id', '=', 'inspection_details.appoinment_id');
                if(isset($request->clientid) && $request->clientid != ''){
                    $inspection = $inspection->whereRaw("(appoinments.patientid ='".$request->clientid."' OR appoinments.doctorid='".$request->clientid."')")->orderBy('appoinments.appoinmentdate','DESC');
                }

                if(isset($request->stappdate) && $request->stappdate != '' ){
                    $date1 = str_replace('/', '-', $request->stappdate);
                    $stappdate = date('Y-m-d', strtotime($date1));
                    $date1 = str_replace('/', '-', $request->endappdate);
                    $endappdate = date('Y-m-d', strtotime($date1));
                    if($request->stappdate != '' && isset($request->endappdate) && $request->endappdate != '' )
                    {
                        $inspection = $inspection->whereRaw("appoinments.appoinmentdate BETWEEN '$stappdate' AND '$endappdate' ");
                    }
                    elseif($request->stappdate != '' && $request->endappdate == ''){
                        $inspection = $inspection->whereRaw("appoinments.appoinmentdate = '$stappdate'");
                    }
                }
                elseif(!isset($request->clientid) || $request->clientid == ''){
                    $inspection = $inspection->whereRaw('Date(appoinments.appoinmentdate) = CURDATE()');
                }else{
                    //$inspection = $inspection->whereRaw('Date(appoinments.appoinmentdate) = CURDATE()');
                }

                $inspectionlist = $inspection->get();
                return view('doctor/inspectionlist')->with('inspectionlist', $inspectionlist);
            }
            elseif(Auth::User()->Role == 'Host'){

                $inspection = DB::table('inspection_details')
                    ->Select('inspection_details.id','inspection_details.appoinment_id', 'inspection_details.chief_complaint','inspection_details.diagnosed_complaint', 'inspection_details.total_price', 'inspection_details.next_appoinment_id','inspection_details.concession', 'appoinments.appoinmentdate', 'appoinments.appointment_desc','appoinments.appointment_start','appoinments.appointment_end')
                    ->addSelect(DB::raw('(SELECT timings FROM appoinment_time WHERE appoinment_time.id = appoinments.appoinment_time) AS appoinment_time'))
                    ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname'))
                    ->addSelect(DB::raw('(SELECT branchname FROM branches WHERE branches.id = appoinments.branchcode) AS branchcode'))
                    ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) As clientnme'))
                    ->addSelect(DB::raw('(SELECT balance_payment FROM client_payment_info WHERE client_payment_info.appointment_id = appoinments.id Order By client_payment_info.created_at DESC LIMIT 1 ) As balence_amt'))
                    ->join('appoinments', 'appoinments.id', '=', 'inspection_details.appoinment_id');

                if(isset($request->clientid) && $request->clientid != ''){
                    $inspection = $inspection->whereRaw("(appoinments.patientid = '".$request->clientid."' OR appoinments.doctorid = '".$request->clientid."')")->orderBy('appoinments.appoinmentdate','DESC');
                }

                if(isset($request->stappdate) && $request->stappdate != '' ){
                    $date1 = str_replace('/', '-', $request->stappdate);
                    $stappdate = date('Y-m-d', strtotime($date1));
                    $date1 = str_replace('/', '-', $request->endappdate);
                    $endappdate = date('Y-m-d', strtotime($date1));
                    if($request->stappdate != '' && isset($request->endappdate) && $request->endappdate != '' )
                    {
                        $inspection = $inspection->whereRaw("appoinments.appoinmentdate BETWEEN '$stappdate' AND '$endappdate' ");
                    }
                    elseif($request->stappdate != '' && $request->endappdate == ''){
                        $inspection = $inspection->whereRaw("appoinments.appoinmentdate = '$stappdate'");
                    }
                }
                elseif(!isset($request->clientid) || $request->clientid == ''){
                    $inspection = $inspection->whereRaw('Date(appoinments.appoinmentdate) = CURDATE()');
                }else{
                    //$inspection = $inspection->whereRaw('Date(appoinments.appoinmentdate) = CURDATE()');
                }
                $inspectionlist = $inspection->get();
                return view('doctor/inspectionlist')->with('inspectionlist', $inspectionlist);
            }
            else{
                return view('myaccount');
            }
        }
        else{
            return view('auth/login');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        //
        if(Auth::User()){
            $this->validate($request, [
                'chiefcomplaint' => 'required',
                'diagnosedcomplaint' => 'required',
                /*'client_note' => 'required',*/
                'totalpayment' => 'required',
                /*'paymentbalence' => 'required'*/

            ]);

            $appdate = '';
            $nxt_appoinment = 0;
            $inspection = new Inspection_model();
            $fixappoinment = new FixAppoinment();
            $inspection_procedure = new Inspectionprocedure_model();

            $otherfind = '';
            $otherfindarr = $request['otherfindings'];
            $cnt = count($otherfindarr);
            for($h=0;$h<$cnt;$h++){
                $otherfind = $otherfind.$otherfindarr[$h];
                if($h != $cnt -1){
                    $otherfind = $otherfind.'*';
                }
            }

            $distype = $request['discount'];
            $concession = "";
            if($distype == 'rs'){
                $concession = $request['prconcession'];
            }else{
                $concession = $request['concession'];
            }
            $ins_inspection = $inspection::create([
                'appoinment_id' => $request['appoinmentid'],
                /*'client_login_time' => $request['clientlogin'],
                'proc_start_time' => $request['procedurestarts'],
                'proc_end_time'=> $request['procedureends'],*/
                'chief_complaint' => $request['chiefcomplaint'],
                'diagnosed_complaint' => $request['diagnosedcomplaint'],
                'other_findings' => $otherfind,
                'purpose_nxt_app' => $request['nxtappntpurpose'],
                'client_note' => $request['client_note'],
                'doctor_note' => $request['doctor_note'],
                'host_note' => $request['host_note'],
                'total_price' => $request['totalpayment'],
                'concession_type' => $request['discount'],
                'concession' => $concession,
                'final_price' => $request['finalpayment'],
                'balance_price' => $request['paymentbalence'],
                'client_payment' => $request['payment'],
                'payment_mode' => $request['paymentmode'],
                'upcoming_price' => $request['upcomingpay'],
                /*'next_appoinment_id' => $nxt_appoinment,*/
                'created_by' => Auth::user()->id

            ]);

            $procedure = $request->treatmentprocedur;
        //        $doctorprice = $request->doctorprice;
            $procedureprice = $request->treatementpri;

            $tobdntreatmentprocedur = $request->tobdntreatmentprocedur;
            /*$tobdndoctorprice = $request->tobdndoctorprice;*/
            $tobdntreatementpri = $request->tobdntreatementpri;

            $procedurecnt = count($procedure);
            $tobprocnt = count($tobdntreatementpri);

            for($i=0;$i<$procedurecnt;$i++)
            {
                $res = $inspection_procedure::create([
                     'inspection_id' => $ins_inspection->id,
                     'procedure_name' => $procedure[$i],
                     'procedure_price' => $procedureprice[$i],
                     /*'doctor_price' => $doctorprice[$i],*/
                     'procedure_type' => 'done',
                     'created_by' => Auth::user()->id,
                    ]);
            }


            for($j=0;$j<$tobprocnt;$j++){
                $res = $inspection_procedure::create([
                    'inspection_id'  => $ins_inspection->id,
                    'procedure_name' => $tobdntreatmentprocedur[$j],
                    'procedure_price' => $tobdntreatementpri[$j],
                   /* 'doctor_price' => $tobdndoctorprice[$j],*/
                    'procedure_type' => 'to_be_done',
                    'created_by' => Auth::user()->id,
                ]);
            }


            $delappoinment = DB::table('appoinments')->where('id',$request['appoinmentid'])->update(['status'=>1]);

            $clientpayment = new ClientPaymentInfo();
            $clientpayment->patient_id = $request['clientid'];
            $clientpayment->appointment_id = $request['appoinmentid'];
            $clientpayment->final_price = $request['totalamtcalc'];
            $clientpayment->paid_payment = $request['payment'];
            $clientpayment->balance_payment = $request['paymentbalence'];
            $clientpayment->paid_date = date('Y-m-d H:i:s');
            $clientpayment->created_by = Auth::User()->id;
            $clientpayment->save();

            if( Auth::User()->Role == 'Doctor')
            {
                $request->session()->flash('alert-success', 'Successfully Saved.');
                return redirect()->action('PagesController@doctorappoinmentlist');
            }
            elseif(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin'){
                $request->session()->flash('alert-success', 'Successfully Saved.');
                if($request->status == 'closed')
                    return redirect()->action('PagesController@doctorappoinmentlist');
                elseif($request->status == 'fixappoinment')
                    return redirect('fixappoinment/'.$request['appoinmentid'].'/edit');

            }
        }else{
            return view('auth/login');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //

        /*try {*/
            $docname = '';

            //$appdet = DB::table('appoinments')->select(DB::raw('CONCAT(registration_details.nametitle, "", registration_details.firstname) AS full_name'),'appoinments.id','appoinments.appoinmentdate','branches.branchname', 'appoinments.host_name', 'appoinments.clientnote', 'appoinment_time.timings', 'appoinments.patientid','appoinments.branchcode' )->join('users', 'users.id', '=','appoinments.patientid')->join('registration_details','registration_details.id', '=', 'users.registerid')->join('branches', 'branches.id', '=', 'appoinments.branchcode')->join('appoinment_time','appoinment_time.id','=','appoinments.appoinment_time')->where('appoinments.id','=',$id)->get();
        if(Auth::check()) {

            $previns = DB::table('appoinments')
                ->select(DB::raw('CONCAT(registration_details.nametitle, "", registration_details.firstname) AS full_name'), 'appoinments.id', 'appoinments.appoinmentdate', 'branches.branchname', 'appoinments.host_name', 'appoinments.clientnote', 'appoinments.patientid', 'appoinments.branchcode', 'appoinments.appointment_start', 'appoinments.appointment_end', 'appoinments.appointment_desc','inspection_details.id as ins_id','inspection_details.chief_complaint', 'inspection_details.diagnosed_complaint','inspection_details.other_findings','inspection_details.purpose_nxt_app', 'inspection_details.client_note','inspection_details.purpose_nxt_app')
                ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.host_name = users.id) As hostname'))
                ->addSelect(DB::raw('(SELECT balance_payment FROM client_payment_info WHERE client_payment_info.patient_id = appoinments.patientid Order By client_payment_info.created_at DESC LIMIT 1 ) As balence_amt'))
                ->join('users', 'users.id', '=', 'appoinments.patientid')
                ->join('inspection_details', 'inspection_details.next_appoinment_id','=','appoinments.id')
                ->join('registration_details', 'registration_details.id', '=', 'users.registerid')->join('branches', 'branches.id', '=', 'appoinments.branchcode')->where('appoinments.id', '=', $id)->first();

            if($previns != ''){
                $procedures_done = DB::table('inspection_procedure')->where('inspection_id',$previns->ins_id )->where('procedure_type','done')->get();
                $procedures_tobe_done = DB::table('inspection_procedure')->where('inspection_id',$previns->ins_id)->where('procedure_type','to_be_done')->get();
            }else{
                $previns = array();$procedures_done = array();$procedures_tobe_done = array();
            }

            $appdet = DB::table('appoinments')
                ->select(DB::raw('CONCAT(registration_details.nametitle, "", registration_details.firstname) AS full_name'), 'appoinments.id', 'appoinments.appoinmentdate', 'branches.branchname', 'appoinments.host_name', 'appoinments.clientnote', 'appoinments.patientid', 'appoinments.branchcode', 'appoinments.appointment_start', 'appoinments.appointment_end', 'appoinments.appointment_desc')
                ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.host_name = users.id) As hostname'))
                ->addSelect(DB::raw('(SELECT balance_payment FROM client_payment_info WHERE client_payment_info.patient_id = appoinments.patientid Order By client_payment_info.created_at DESC LIMIT 1 ) As balence_amt'))
                ->join('users', 'users.id', '=', 'appoinments.patientid')->join('registration_details', 'registration_details.id', '=', 'users.registerid')->join('branches', 'branches.id', '=', 'appoinments.branchcode')->where('appoinments.id', '=', $id)->get();
            //print_r($appdet);exit;
            $doctornme = DB::table('appoinments')->select(DB::raw('CONCAT(registration_details.nametitle,"",registration_details.firstname) AS docname'))->join('users', 'users.id', '=', 'appoinments.doctorid')->join('registration_details', 'registration_details.id', '=', 'users.registerid')->where('appoinments.id', '=', $id)->get();

            $apptimings = DB::table('appoinment_time')->lists('timings', 'id');
            //echo '<pre>';print_r($appdet);exit;
            foreach ($doctornme as $docnme) {
                $docname = $docnme->docname;
            }

            return view('doctor/inspection')->with('appdet', $appdet)->with('docname', $docname)->with('apptimings', $apptimings)->with('previns', $previns)->with('procedures_done',$procedures_done)->with('procedures_tobe_done',$procedures_tobe_done);
        }else{
            return redirect('auth/login');
        }
            //return $edituserdet;
        /*}
        catch(\Exception $e){
            \session()->flash('alert-success', 'Something went wrong while Getting information. Kindly contact administrator.');
            return redirect('userlisting');
        }*/
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Edit inspection data
        $docname = '';

        $procedure_det = new Inspectionprocedure_model();

        $procedures = array();

        $inspection = DB::table('inspection_details')
            ->Select('inspection_details.id','inspection_details.appoinment_id', 'inspection_details.client_login_time', 'inspection_details.proc_start_time','inspection_details.proc_end_time', 'inspection_details.chief_complaint', 'inspection_details.diagnosed_complaint','inspection_details.other_findings','inspection_details.concession_type','inspection_details.concession','inspection_details.purpose_nxt_app' ,'inspection_details.client_note' ,'inspection_details.doctor_note','inspection_details.host_note', 'inspection_details.balance_price','inspection_details.total_price', 'inspection_details.client_payment', 'inspection_details.payment_mode','inspection_details.upcoming_price','inspection_details.next_appoinment_id', 'appoinments.appoinmentdate','appoinments.appointment_start','appoinments.appointment_end','appoinments.appointment_desc', 'appoinments.patientid','appoinments.host_name','appoinments.doctorid','appoinments.branchcode AS brcode')
            ->addSelect(DB::raw('(SELECT timings FROM appoinment_time WHERE appoinment_time.id = appoinments.appoinment_time) AS appoinment_time'))
            ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname'))
            ->addSelect(DB::raw('(SELECT branchname FROM branches WHERE branches.id = appoinments.branchcode) AS branchcode'))
            ->addSelect(DB::raw('(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) As clientnme'))
            ->addSelect(DB::raw('(SELECT CONCAT(nametitle,"",firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.host_name = users.id) As hostname'))
            ->addSelect(DB::raw('(SELECT appoinmentdate FROM appoinments WHERE appoinments.id = inspection_details.next_appoinment_id ) AS nxt_appoinment_date'))
            ->addSelect(DB::raw('(SELECT appoinment_time FROM appoinments WHERE appoinments.id = inspection_details.next_appoinment_id ) AS nxt_appoinment_time'))
            ->addSelect(DB::raw('(SELECT balance_payment FROM client_payment_info WHERE client_payment_info.patient_id = appoinments.patientid Order By client_payment_info.created_at DESC LIMIT 1,1 ) As balence_amt'))
            ->join('appoinments', 'appoinments.id', '=', 'inspection_details.appoinment_id')->where('inspection_details.id', $id);
        $inspectiondet = $inspection->get();


        $appdet = DB::table('appoinments')->select(DB::raw('CONCAT(registration_details.nametitle, "", registration_details.firstname) AS full_name'),'appoinments.id','appoinments.appoinmentdate','branches.branchname', 'appoinments.host_name', 'appoinments.clientnote', 'appoinment_time.timings', 'appoinments.patientid','appoinments.branchcode' )->join('users', 'users.id', '=','appoinments.patientid')->join('registration_details','registration_details.id', '=', 'users.registerid')->join('branches', 'branches.id', '=', 'appoinments.branchcode')->join('appoinment_time','appoinment_time.id','=','appoinments.appoinment_time')->where('appoinments.id','=',$id)->get();
        $doctornme = DB::table('appoinments')->select(DB::raw('CONCAT(registration_details.nametitle,"",registration_details.firstname) AS docname'))->join('users', 'users.id','=', 'appoinments.doctorid')->join('registration_details','registration_details.id','=', 'users.registerid')->where('appoinments.id','=',$id)->get();

        $apptimings = DB::table('appoinment_time')->lists('timings','id');
        //echo '<pre>';print_r($appdet);exit;
        $procedures_done = DB::table('inspection_procedure')->where('inspection_id',$id )->where('procedure_type','done')->get();
        $procedures_tobe_done = DB::table('inspection_procedure')->where('inspection_id',$id )->where('procedure_type','to_be_done')->get();

        return view('doctor/editinspection')->with('apptimings', $apptimings)->with('procedures_done', $procedures_done)->with('procedures_tobe_done', $procedures_tobe_done)->with('inspectiondet', $inspectiondet);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $this->validate($request, [
            'chiefcomplaint' => 'required',
            'diagnosedcomplaint' => 'required',
            /*'client_note' => 'required',*/
            'totalpayment' => 'required',
            'paymentbalence' => 'required'

        ]);


       /* try {*/
        $appdate = '';
        $nxt_appoinment = 0;
        $inspection = new Inspection_model();
        $fixappoinment = new FixAppoinment();
        $inspection_procedure = new Inspectionprocedure_model();

        $inspection_upd = $inspection::find($id);

        $otherfind = '';
        $otherfindarr = $request['otherfindings'];
        $cnt = count($otherfindarr);
        for($h=0;$h<$cnt;$h++){
            $otherfind = $otherfind.$otherfindarr[$h];
            if($h != $cnt -1){
                $otherfind = $otherfind.'*';
            }
        }

        $distype = $request['discount'];
        $concession = "";
        if($distype == 'rs'){
            $concession = $request['prconcession'];
        }else{
            $concession = $request['concession'];
        }

            $inspection_upd->appoinment_id = $request['appoinmentid'];
            /*$inspection_upd->client_login_time = $request['clientlogin'].' '.$request['logendmeridian'];
            $inspection_upd->proc_start_time = $request['procedurestarts'].' '.$request['prstendmeridian'];
            $inspection_upd->proc_end_time = $request['procedureends'].' '.$request['predendmeridian'];*/
            $inspection_upd->chief_complaint = $request['chiefcomplaint'];
            $inspection_upd->diagnosed_complaint = $request['diagnosedcomplaint'];
            $inspection_upd->other_findings = $otherfind;
            $inspection_upd->purpose_nxt_app = $request['nxtappntpurpose'];
            $inspection_upd->client_note = $request['client_note'];
            $inspection_upd->doctor_note = $request['doctor_note'];
            $inspection_upd->host_note = $request['host_note'];
            $inspection_upd->total_price = $request['totalpayment'];
            $inspection_upd->concession_type = $request['discount'];
            $inspection_upd->concession = $concession;
            $inspection_upd->final_price = $request['finalpayment'];
            $inspection_upd->balance_price = $request['paymentbalence'];
            $inspection_upd->client_payment = $request['payment'];
            $inspection_upd->upcoming_price = $request['upcomingpay'];
            $inspection_upd->payment_mode = $request['paymentmode'];
            $inspection_upd->next_appoinment_id = $nxt_appoinment;
            $inspection_upd->updated_by = Auth::user()->id;
            $inspection_upd->save();

            $procedure = $request->treatmentprocedur;
            /*$doctorprice = $request->doctorprice;*/
            $procedureprice = $request->treatementpri;

            $tobdntreatmentprocedur = $request->tobdntreatmentprocedur;
            /*$tobdndoctorprice = $request->tobdndoctorprice;*/
            $tobdntreatementpri = $request->tobdntreatementpri;

            $procedurecnt = count($procedure);
            $tobprocnt = count($tobdntreatementpri);

            $insp_procedure = $inspection_procedure::where('inspection_id', $id)->delete();
            for($i=0;$i<$procedurecnt;$i++)
            {
                $res = $inspection_procedure::create([
                    'inspection_id' => $id,
                    'procedure_name' => $procedure[$i],
                    'procedure_price' => $procedureprice[$i],
                    /*'doctor_price' => $doctorprice[$i],*/
                    'created_by' => Auth::user()->id,
                ]);
            }

            for($j=0;$j<$tobprocnt;$j++){
                $res = $inspection_procedure::create([
                    'inspection_id'  => $id,
                    'procedure_name' => $tobdntreatmentprocedur[$j],
                    'procedure_price' => $tobdntreatementpri[$j],
                    /*'doctor_price' => $tobdndoctorprice[$j],*/
                    'procedure_type' => 'to_be_done',
                    'created_by' => Auth::user()->id,
                ]);
            }

            $clientpaymentobj = new ClientPaymentInfo();
            $clientpayment = $clientpaymentobj::where('appointment_id', $request['appoinmentid'])->first();
            $clientpayment->final_price = $request['totalamtcalc'];
            $clientpayment->paid_payment = $request['payment'];
            $clientpayment->balance_payment = $request['paymentbalence'];
            $clientpayment->paid_date = date('Y-m-d H:i:s');
            $clientpayment->updated_by = Auth::User()->id;
            $clientpayment->save();

            $date1 = str_replace('/', '-', $request->appdate);
            $appdate = date('Y-m-d', strtotime($date1));

            $request->session()->flash('alert-success', 'Inspection Details Updated successfully!');
            return redirect()->action('InspectionController@index');
        /*}
        catch(\Exception $e){
            $request->session()->flash('alert-success', 'Something went wrong while Update. Check your input or contact administrator.');
        }*/
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $inspection = new Inspection_model();
        $ins = $inspection::find($id);
        $ret = $ins->delete();
        if($ret){
            \session()->flash('alert-success', 'Inspection Details Deleted successfully!');
            return redirect()->action('InspectionController@index');
        }
        else{
            \session()->flash('alert-success', 'Error While Deleting. Kindly try again!');
            return redirect()->action('InspectionController@index');
        }
    }
}
