<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


Route::group(['before' => 'auth','after'=>'no-cache'], function () {
    Route::get('/',
        ['as' => '/',
            'uses' => 'PagesController@getIndex'
            //return view('auth/login');
        ]);

//Route::get('/', function(){
//    return view('auth/login');
//});

//Route::get('registration',[
//   'as' => 'registration',
//    'uses' => 'PagesController@getRegister'
//]);
//
////Route::get('myaccount',
//    ['as' => 'myaccount',
//    'uses' => 'PagesController@getMyaccount']
//);

    /*Redirect while successfull login*/
    Route::get('home', [
        'as' => 'home',
        'uses' => 'PagesController@redirectacc'
    ]);

    Route::get('auth/auth/register',
        ['as' => 'register',
            'uses' => 'PagesController@getReg']
    );

    Route::get('auth/auth/login',
        ['as' => 'login',
            'uses' => 'PagesController@getIndex']
    );

    Route::get('addStaff', [
        'as' => 'addStaff',
        'uses' => 'PagesController@addStaff'
    ]);

    Route::get('appoinmentlist', [
        'as' => 'appoinmentlist',
        'uses' => 'PagesController@appoinmentlist'
    ]);

    Route::get('settings',[
        'as' => 'settings',
        'uses' => 'PagesController@settings'
    ]);

    /*Indicidial doctor appoinment list page*/
    Route::get('docappoinmentlist', [
        'as' => 'docappoinmentlist',
        'uses' => 'PagesController@doctorappoinmentlist'
    ]);

    Route::get('deletappoinment/{id}', function ($id) {
        if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin' || Auth::User()->Role == 'client') {
            $data = DB::table('appoinments')->where('id', $id)->update(['delet' => 1]);

            \session()->flash('alert-success', 'Appointment deleted successfully!');
            if(Auth::User()->Role == 'client'){
                return redirect()->route('myappointments');
            }else{
                return redirect()->route('appoinmentlist');
            }

        }else{
            \session()->flash('alert-danger', "You don't have access for this action. Kindly contact administrator!");
            if(Auth::User()->Role == 'client'){
                return redirect()->route('myappointments');
            }else{
                return redirect()->route('appoinmentlist');
            }
        }
    });

//Delete source

    Route::get('hidesource/{id}', function ($id) {
        if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
            $data = DB::table('sourceofreference')->where('id', $id)->update(['hide' => 'yes']);

            \session()->flash('alert-success', 'Source of Reference deleted successfully!');
            return redirect('sourceofref');
        }
    });

    //Delete procedure
    Route::get('deletprocedure/{id}', function($id){
        if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin') {
            $data = DB::table('procedure_details')->where('id', $id)->update(['hide' => 'yes']);

            \session()->flash('alert-success', 'Procedure deleted successfully!');
            return redirect('procedures');
        }
    });

//Edit source
    Route::any('editsourceofref/{id}', function($id){
        if(Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin'){
            $val = $_POST['editsourceofref'];
            $data = DB::table('sourceofreference')->where('id',$id)->update(['sourceofreference'=>$val]);
            \session()->flash('alert-success', 'Source of Reference Modified successfully!');
            return redirect('sourceofref');
        }
    });

//Route::POST('words/means',function(){
//   $keyword = Str::lower(Input::get('auto'));
//    $models = Word::where('word', '=', $keyword)->orderby('word')->take(10)->skip(0)->get();
//    $count = count($models);
//    return View::make('Dictionary.definition.means')->with("contents", $models)->with("counts", $count);
//});

    Route::any('getdata', function () {
        if (Auth::User()) {
            $term = strtolower(Input::get('term'));
            //Check if any matches found  in the database table
            $data = DB::table("registration_details")->join("users", "users.registerid", "=", "registration_details.id")->select('registration_details.nametitle', 'registration_details.firstname', 'registration_details.lastnametitle', 'registration_details.lastname','registration_details.branchcode', 'users.id', 'users.name', 'users.Mobile_number', 'users.email')->whereRaw("(firstname LIKE '".$term."%' OR users.Mobile_number LIKE '%".$term."%')")->whereRaw("(users.Role = 'Client' OR users.Role = 'Doctor')")->take(30)->get();
//    $data = $data1->addSelect(DB::raw("(SELECT id FROM users WHERE users.registerid = registration_details.id ) AS id"))->where('firstname', 'LIKE', $term.'%')->groupBy('registration_details.firstname')->take(10)->get();
            $clientdata = array();
            foreach ($data as $v) {
                //$return_array[] = array('value'=> $v->firstname);
                $name['value'] = $v->nametitle . $v->firstname .' '.$v->lastname. " (" . $v->Mobile_number . ")";//" (" . $v->name . ")";
                $name['id'] = $v->id;
                $name['nametitle'] = $v->nametitle;
                $name['firstname'] = $v->firstname;
                $name['lastnametitle'] = $v->lastnametitle;
                $name['lastname'] = $v->lastname;
                $name['Mobile_number'] = $v->Mobile_number;
                $name['email'] = $v->email;
                $name['branchcode'] = $v->branchcode;

                array_push($clientdata, $name);
            }
            return Response::json($clientdata);
        }
        else{
            $clientdata = array();
            $name['value'] = 'Kindly Logout and Login';
            array_push($clientdata, $name);
            return Response::json($clientdata);
        }
    });

    Route::any('getstaffdata', function () {
        if (Auth::User()) {
            $term = strtolower(Input::get('term'));
            //Check if any matches found  in the database table
            $data = DB::table("registration_details")->join("users", "users.registerid", "=", "registration_details.id")->select('registration_details.nametitle', 'registration_details.firstname', 'registration_details.lastnametitle', 'registration_details.lastname','registration_details.branchcode', 'users.id', 'users.name', 'users.Mobile_number', 'users.email')->whereRaw("(firstname LIKE '".$term."%' OR users.Mobile_number LIKE '%".$term."%')")->whereRaw("(users.Role != 'Client')")->take(30)->get();
//    $data = $data1->addSelect(DB::raw("(SELECT id FROM users WHERE users.registerid = registration_details.id ) AS id"))->where('firstname', 'LIKE', $term.'%')->groupBy('registration_details.firstname')->take(10)->get();
            $clientdata = array();
            foreach ($data as $v) {
                //$return_array[] = array('value'=> $v->firstname);
                $name['value'] = $v->nametitle . $v->firstname .' '.$v->lastname. " (" . $v->Mobile_number . ")";//" (" . $v->name . ")";
                $name['id'] = $v->id;
                $name['nametitle'] = $v->nametitle;
                $name['firstname'] = $v->firstname;
                $name['lastnametitle'] = $v->lastnametitle;
                $name['lastname'] = $v->lastname;
                $name['Mobile_number'] = $v->Mobile_number;
                $name['email'] = $v->email;
                $name['branchcode'] = $v->branchcode;

                array_push($clientdata, $name);
            }
            return Response::json($clientdata);
        }
        else{
            $clientdata = array();
            $name['value'] = 'Kindly Logout and Login';
            array_push($clientdata, $name);
            return Response::json($clientdata);
        }
    });

//Load host list
    Route::any('hostlist/{appdt}/{br}', function($appdt, $br){
        $hostarr = DB::table("users")->join('registration_details','registration_details.id','=','users.registerid')->where('users.Role','Host')->select('registration_details.*','users.*')->get();
        if(count($hostarr) > 0)
            echo json_encode($hostarr);
        else{
            $hostarr = array();
            echo json_encode($hostarr);
        }

    });

    Route::any('tempappointment/{stdt}/{enddt}/{txt}/{br}',function($stdt, $enddt, $txt,$br){

        $prevapp = DB::table('appoinments')->where('branchcode', $br)->where('delet','0')->where('appointment_start', $stdt)->get();
        if(count($prevapp) < 2 ){
            $apparr = array();
            $apparr['start'] = $stdt;
            $apparr['end'] = $enddt;
            $apparr['appoint'] = $txt;
            \session()->put('tempapp', $apparr);
            //print_r(\session()->get('tempapp'));
        }else{
            echo 'fail';
        }

    });

    //Get doctor availabiity while edit
    Route::any('getdocavail/{branch}/{doc}', function($br, $doc){
        $docavail = DB::table('doctor_availability_daywise')->where('user_id', $doc)->where('hide', 'no')->where('branchcode',$br)->get();
        return json_encode($docavail);
    });

    //Get doctor and host availability
    Route::any('getavailability/{docid}/{host}/{dt}/{appid}', function($docid, $host, $dt,$appid){

        $day = ucfirst(date("l", strtotime($dt)));$avail = array();$avail = array();
        $docavail = DB::table('doctor_availability_daywise')->where('user_id', $docid)->where('day', $day)->where('hide', 'no')->get();
        $docdets = DB::table('registration_details')->join('users','users.registerid','=','registration_details.id')->join('branches','branches.branchcode','=','registration_details.branchcode')->select(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'branches.branchname')->where('users.id',$docid)->get();
        foreach($docdets as $docdet){
            $avail['doc']['branch'] = $docdet->branchname.' Branch';
            $avail['doc']['name'] = $docdet->firstname;
        }
        if(count($docavail)){
            foreach($docavail as $doctor){
                //echo $doctor->day_off;exit;
                if($doctor->day_off == 'yes'){
                    $avail['doc'][$doctor->branchcode]['fhour'] = '00';
                    $avail['doc'][$doctor->branchcode]['fmin'] = '00';
                    $avail['doc'][$doctor->branchcode]['fap'] = 'AM';
                    $avail['doc'][$doctor->branchcode]['thour'] = '00';
                    $avail['doc'][$doctor->branchcode]['tmin'] = '00';
                    $avail['doc'][$doctor->branchcode]['tap'] = 'PM';
                    $avail['doc'][$doctor->branchcode]['day_off'] = $doctor->day_off;
                }else{
                    $avail['doc'][$doctor->branchcode]['fhour'] = $doctor->fhour;
                    $avail['doc'][$doctor->branchcode]['fmin'] = $doctor->fmin;
                    $avail['doc'][$doctor->branchcode]['fap'] = $doctor->fap;
                    $avail['doc'][$doctor->branchcode]['thour'] = $doctor->thour;
                    $avail['doc'][$doctor->branchcode]['tmin'] = $doctor->tmin;
                    $avail['doc'][$doctor->branchcode]['tap'] = $doctor->tap;
                    $avail['doc'][$doctor->branchcode]['day_off'] = $doctor->day_off;
                }

            }
        }
        else{
            $avail['doc']['day_off'] = 'No data updated. Kindly call Doctor or branch';
        }

        $hostavail = DB::table('doctor_availability_daywise')->where('user_id', $host)->where('day', $day)->where('hide', 'no')->get();
        $hostdets = DB::table('registration_details')->join('users','users.registerid','=','registration_details.id')->join('branches','branches.branchcode','=','registration_details.branchcode')->select(DB::raw("CONCAT_WS('', registration_details.nametitle, registration_details.firstname) AS firstname"),'branches.branchname')->where('users.id',$host)->get();

        foreach($hostdets as $hostdet){
            $avail['host']['branch'] = $hostdet->branchname.' Branch';
            $avail['host']['name'] = $hostdet->firstname;
        }
        if(count($hostavail)){
            foreach($hostavail as $hostdt){
                if($hostdt->day_off == 'yes'){
                    $avail['host'][$hostdt->branchcode]['fhour'] = '00';
                    $avail['host'][$hostdt->branchcode]['fmin'] = '00';
                    $avail['host'][$hostdt->branchcode]['fap'] = 'AM';
                    $avail['host'][$hostdt->branchcode]['thour'] = '00';
                    $avail['host'][$hostdt->branchcode]['tmin'] = '00';
                    $avail['host'][$hostdt->branchcode]['tap'] = 'PM';
                    $avail['host'][$hostdt->branchcode]['day_off'] = $hostdt->day_off;
                }else{
                    $avail['host'][$hostdt->branchcode]['fhour'] = $hostdt->fhour;
                    $avail['host'][$hostdt->branchcode]['fmin'] = $hostdt->fmin;
                    $avail['host'][$hostdt->branchcode]['fap'] = $hostdt->fap;
                    $avail['host'][$hostdt->branchcode]['thour'] = $hostdt->thour;
                    $avail['host'][$hostdt->branchcode]['tmin'] = $hostdt->tmin;
                    $avail['host'][$hostdt->branchcode]['tap'] = $hostdt->tap;
                    $avail['host'][$hostdt->branchcode]['day_off'] = $hostdt->day_off;
                }

            }
        }
        else{
            $avail['host']['day_off'] = 'No data updated. Kindly call Host or branch';
        }
        $apdate = date('Y-m-d', strtotime($dt));
        $availqry = DB::table('appoinments')->join('users','users.id','=','appoinments.doctorid')
            ->addSelect(DB::raw('(SELECT CONCAT(nametitle,"",firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname'))
            ->addSelect(DB::raw('(SELECT CONCAT(nametitle,"",firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) As patient'),'appoinments.*')
            ->addSelect(DB::raw('(SELECT branchname FROM branches WHERE appoinments.branchcode = branches.branchcode) As branch'))
            ->where('appoinments.doctorid', $docid)->where('appoinments.delet','0')->where('appoinmentdate', $apdate);
        if($appid != 0){
            $avail['appointment'] = $availqry->where('appoinments.id','!=',$appid)->orderBy('appointment_start', 'ASC')->get();
        }else{
            $avail['appointment'] = $availqry->orderBy('appointment_start', 'ASC')->get();
        }

        return json_encode($avail);
    });

    /*$e->id = $row['id'];
    $e->text = $row['name'];
    $e->start = $row['start'];
    $e->end = $row['end'];
    $e->resource = $row['resource'];*/
    Route::any('loadappointments/{appdt}/{br}/{edit}', function($appdt, $br, $edit){

        $dt = date('Y-m-d', strtotime($appdt));
        $result = DB::table('appoinments')
            ->select(DB::raw('(SELECT CONCAT(registration_details.nametitle,"",registration_details.firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname'),'appoinments.id','appoinments.clientnote','appoinments.appointment_start','appoinments.appointment_end')
            ->addSelect(DB::raw('(SELECT CONCAT(registration_details.nametitle,"",registration_details.firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) As clientnme'))
            ->addSelect(DB::raw('(SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.appointment_id = appoinments.id ORDER BY updated_at DESC LIMIT 0,1 )as status'))
            ->leftjoin('appointment_status','appointment_status.appointment_id',' = ','appoinments.id')
            ->where('appoinmentdate', $dt)
            ->where('branchcode', $br)
            ->where('delet','0')
            ->where('appointment_status.appointment_status', '!=','closed')->groupBy('appointment_status.appointment_id')->get();
        class Event {}
        $events = array();

        foreach($result as $row) {
            if($edit == 1){
                if($row->status == 'open' || $row->status == 'postponed'){
                    $e = new Event();
                    $e->id = $row->id;
                    $e->text = $row->clientnme.' appointment with '.$row->doctorname.', '.$row->clientnote;
                    $e->start = $row->appointment_start;
                    $e->end = $row->appointment_end;
                    /*$e->resource = $row->resource;*/
                    $events[] = $e;
                }
            }else{
                    if($row->status == 'open'){ //|| $row->status == 'postponed'
                        $e = new Event();
                        $e->id = $row->id;
                        $e->text = $row->clientnme.' appointment with '.$row->doctorname.', '.$row->clientnote;
                        $e->start = $row->appointment_start;
                        $e->end = $row->appointment_end;
                        /*$e->resource = $row->resource;*/
                        $events[] = $e;
                    }
                }
        }

        echo json_encode($events);
        //$e = (object) array('id'=>'','text'=>'',)
    });

    //Client appointments for selected date
    Route::any('clientappointment/{curdate}/{usid}/{appid}', function($curdt, $usid, $appid){
        $dt = date('Y-m-d', strtotime($curdt));
        $resultqry = DB::table('appoinments')
            ->select(DB::raw('(SELECT CONCAT(registration_details.nametitle,"",registration_details.firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname'),'appoinments.patientid','appoinments.clientnote', 'appoinments.appointment_start', 'appoinments.appointment_end','branches.branchname',DB::raw('(SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.appointment_id = appoinments.id ORDER BY appointment_status.updated_at DESC LIMIT 0,1) AS stat'))
            ->join("branches", "branches.branchcode", "=", "appoinments.branchcode")
            ->where('appoinments.patientid',$usid)
            ->where('appoinments.delet','0')
            ->where('appoinments.appoinmentdate', $dt);
        if($appid != 0){
            $resultqry = $resultqry->where('appoinments.id','!=',$appid);
        }
        $result = $resultqry->orderBy('appoinments.appointment_start', 'ASC')->get();
        echo json_encode($result);
    });

    Route::any('getappointments/{dt}', function($dt){
       if(Auth::User()){
           $data = DB::table("appoinments")->where('appoinmentdate', $dt)->where('delet','0')->get();
            $events = array();$e = array();
           foreach($data as $row) {

               $e['id'] = $row->id;
               $e['text'] = "";
               $e['start'] = $row->appoinment_st;
               $e['end'] = $row->appointment_end;
               $e['tags']['status'] = $row->status;
               $e['tags']['doctor'] = $row['doctor_name'];
               $events[] = $e;
           }
           echo json_encode($events);
       }
    });

    //Get Usernames to add remainder
    Route::any('getusernames', function(){
       if(Auth::User()){
           $term = strtolower(Input::get('term'));
           //Check if any matches found  in the database table
           $data = DB::table("registration_details")->join("users", "users.registerid", "=", "registration_details.id")->distinct()->select('registration_details.nametitle', 'registration_details.firstname', 'registration_details.lastname', 'users.id', 'users.name', 'users.Mobile_number', 'users.email','users.Role')->where('firstname', 'LIKE', $term . '%')->groupBy('registration_details.firstname')->take(10)->get();
           $clientdata = array();
           foreach ($data as $v) {
               //$return_array[] = array('value'=> $v->firstname);
               $name['value'] = $v->nametitle . $v->firstname . ' ' . $v->lastname ;
               $name['id'] = $v->id;
               $name['nametitle'] = $v->nametitle;
               $name['firstname'] = $v->firstname;
               $name['lastname'] = $v->lastname;
               $name['Mobile_number'] = $v->Mobile_number;
               $name['email'] = $v->email;
               $name['role'] = $v->Role;

               array_push($clientdata, $name);
           }
           return Response::json($clientdata);
       }
    });

    //Block to get procedure details
    Route::any('getprocedure', function(){
        if (Auth::User()) {
            $term = strtolower(Input::get('term'));
            //Check if any matches found  in the database table
            $data = DB::table("procedure_details")->where('procedure_name', 'LIKE', $term . '%')->take(10)->get();
            $clientdata = array();
            foreach($data as $value){
                $procedure['value'] = $value->procedure_name;
                $procedure['id'] = $value->id;
                $procedure['price'] = $value->procedure_price;

                array_push($clientdata, $procedure);
            }
            return Response::json($clientdata);
        }
    });

    Route::any('addtimings/{sunday1}/{monday1}/{tuesday1}/{wednesday1}/{thursday1}/{friday1}/{satday1}/', function($sunday,$monday,$tuesday,$wednesday,$thursday, $friday, $satday){
        echo $res = 'hi';
    });

    Route::any('getclientappoinment/{id}/{date}/', function($clientid, $date){
        if(Auth::User()){
            //Get client's appoinment
            $getclientappoinments = DB::table("appoinments")->select("registration_details.firstname", "appoinment_time.timings", "branches.branchname")->join("registration_details", "appoinments.doctorid" ,"=", "registration_details.id" )->join("appoinment_time", "appoinments.appoinment_time", "=","appoinment_time.id")->join("branches", "branches.id", "=", "appoinments.branchcode")->where("appoinments.patientid", $clientid)->where('appoinments.delet','0');
            if($date != 0)
            {
                $appdateval = date('Y-m-d', strtotime($date));
                $getclientappoinments = $getclientappoinments->where("appoinments.appoinmentdate", $appdateval);
            }
            $clienthistory = $getclientappoinments->orderBy('appoinmentdate', 'desc')->take(1)->get();
            $clienthistorycnt = $getclientappoinments->count();

            if($clienthistorycnt > 0)
            {
                foreach($clienthistory as $appoinment)
                {
                    //$respons = ' Already Taken an Appoinment : Doctor Name : '.$appoinment->firstname.', Branch : '.$appoinment->branchname.', Date : '.$date. ', Time : '.$appoinment->timings.' Continue Anyway?';
                    $respons = 'Client Already taken an appointment proceed?';
                }
                return $respons;
            }
            else{
                echo 0;
            }

        }
        else{

        }
    });

    Route::any('hideremainder/{remainderid}', function($remainderid){
       if(Auth::User()){
           $hideremainder = DB::table('remainders')->where('id',$remainderid)->update(['status'=>'closed']);
           \session()->flash('alert-success', 'Changed as seen');
           return redirect('remainders');
       }
    });

    //Functionality to check all possible error before fix appoinment
    Route::any('checkappoinment/{appdate}/{branchid}/{doctorid}/{clientid}/{host}/{appid}', function($appdate, $branchid, $docid, $clientid, $host, $appid){
        /*$appointmentdet = \session()->get('tempapp');
        $apdate = date('Y-m-d', strtotime($appdate));
        $chkappoinments = DB::table("appoinments")->select()->where('appoinmentdate', $apdate)->where('doctorid',$docid)->where('appointment_start', $appointmentdet['start'])->where('appointment_end', $appointmentdet['end'])->get();
        print_r($chkappoinments);*/
        if(Auth::User() && (Auth::User()->Role == 'admin' || Auth::User()->Role == 'Doctor' || Auth::User()->Role == 'super_admin' || Auth::User()->Role == 'Host' )){
            $errormsg = '<div class="alert alert-danger"><strong>Whoops!</strong> There were some problems with your input.<br><ul>';
            $apdate = date('Y-m-d', strtotime($appdate));
            $ret[0] = 'success';$ret[1] = 'success';$a = 0;
            $appointmentdet = \session()->get('tempapp');

            $chkappoinments = DB::table("appoinments")->select()->where('appoinmentdate', $apdate)->where('doctorid',$docid)->where('delet','0')->where('appointment_start', $appointmentdet['start'])->where('appointment_end', $appointmentdet['end']);
            if($appid > 0){ $chkappoinments = $chkappoinments->where('id','!=',$appid); }
            $chkappoinments = $chkappoinments->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
            $chkappoinments1 = DB::table("appoinments")->select()->where('appoinmentdate', $apdate)->where('doctorid',$docid)->where('delet','0')->where('appointment_start','<',$appointmentdet['start'])->where('appointment_end','>' ,$appointmentdet['start']);
            if($appid > 0){ $chkappoinments1 = $chkappoinments1->where('id','!=',$appid); }
            $chkappoinments1 = $chkappoinments1->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
            $chkappoinments2 = DB::table("appoinments")->select()->where('appoinmentdate', $apdate)->where('doctorid',$docid)->where('delet','0')->where('appointment_start','<',$appointmentdet['end'])->where('appointment_end','>' ,$appointmentdet['end']);
            if($appid > 0){ $chkappoinments2 = $chkappoinments2->where('id','!=',$appid); }
            $chkappoinments2 = $chkappoinments2->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();

            if(count($chkappoinments) > 0){
                $ret[0] = 'dontsubmit';$a=1;
                $errormsg = $errormsg.'<li>Doctor ';
            }
            if(count($chkappoinments1) > 0 && $a==0){
                $ret[0] = 'dontsubmit';$a=1;
                $errormsg = $errormsg.'<li>Doctor ';
            }
            if(count($chkappoinments2) > 0 && $a==0){
                $ret[0] = 'dontsubmit';$a=1;
                $errormsg = $errormsg.'<li>Doctor ';
            }

            $chkappoinments = DB::table("appoinments")->select()->where('appoinmentdate', $apdate)->where('host_name',$host)->where('delet','0')->where('appointment_start', $appointmentdet['start'])->where('appointment_end', $appointmentdet['end']);
            if($appid > 0){ $chkappoinments = $chkappoinments->where('id','!=',$appid); }
            $chkappoinments = $chkappoinments->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
            $chkappoinments1 = DB::table("appoinments")->select()->where('appoinmentdate', $apdate)->where('host_name',$host)->where('delet','0')->where('appointment_start','<',$appointmentdet['start'])->where('appointment_end','>' ,$appointmentdet['start']);
            if($appid > 0){ $chkappoinments1 = $chkappoinments1->where('id','!=',$appid); }
            $chkappoinments1 = $chkappoinments1->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
            $chkappoinments2 = DB::table("appoinments")->select()->where('appoinmentdate', $apdate)->where('host_name',$host)->where('delet','0')->where('appointment_start','<',$appointmentdet['end'])->where('appointment_end','>' ,$appointmentdet['end']);
            if($appid > 0){ $chkappoinments2 = $chkappoinments2->where('id','!=',$appid); }
            $chkappoinments2 = $chkappoinments2->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
            //echo $chkappoinments->count();

            if(count($chkappoinments) > 0){
                $ret[0] = 'dontsubmit';
                if($a == 0){ $errormsg = $errormsg.'<li>Host '; }else{ $errormsg = $errormsg.' or Host '; }
            }
            if(count($chkappoinments1) > 0){
                $ret[0] = 'dontsubmit';
                if($a == 0){ $errormsg = $errormsg.'<li>Host '; }else{ $errormsg = $errormsg.' or Host '; }
            }
            if(count($chkappoinments2) > 0){
                $ret[0] = 'dontsubmit';
                if($a == 0){ $errormsg = $errormsg.'<li>Host'; }
                else{ $errormsg = $errormsg.' or Host '; }
            }

            if( $ret[0] === 'dontsubmit'){
                $errormsg = $errormsg.'already have appoinment on that time.</li>';
            }

            /*Check if patient */
            $chkpatient = DB::table('appoinments')->select(DB::raw('(SELECT CONCAT(registration_details.nametitle,"",registration_details.firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname'),'appoinments.patientid','appoinments.clientnote', 'appoinments.appointment_start', 'appoinments.appointment_end','branches.branchname')->join("branches", "branches.branchcode", "=", "appoinments.branchcode")->where('appoinments.patientid',$clientid)->where('appoinments.delet','0')->where('appoinments.appoinmentdate', $apdate)->orderBy('appoinments.appointment_start','ASC');
            if($appid > 0){ $chkpatient = $chkpatient->where('appoinments.id','!=',$appid); }
            $chkpatient = $chkpatient->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
            if(count($chkpatient) > 0){
                foreach($chkpatient as $patdet){
                    $ret[1] = 'errpatient';
                    $errormsg = $errormsg.'<li>Client already have appointment with'.$patdet->doctorname.' in '.$patdet->branchname.' at '.substr($patdet->appointment_start, strpos($patdet->appointment_start, " ") + 1).' - '.substr($patdet->appointment_end, strpos($patdet->appointment_end, " ") + 1).'</li>';
                }

            }

            /*check for continuous appointments other branch*/
            $btst = date('Y-m-d H:i:s', strtotime( $appointmentdet["start"]) - 3540);$bted = date('Y-m-d H:i:s', strtotime( $appointmentdet["start"]) + 3540);
            $continuous = DB::table("appoinments")->where('appoinmentdate', $apdate)->where('doctorid',$docid)->where('delet','0')->where('branchcode','!=',$branchid)->whereRaw("((appointment_start BETWEEN '".$btst."' AND '".$bted."') OR (appointment_end BETWEEN '".$btst."' AND '".$bted."' ))")->where('branchcode','!=',$branchid)->orderBy('appointment_start', 'ASC');
            if($appid > 0){ $continuous = $continuous->where('appoinments.id', '!=', $appid); }
            $continuous = $continuous->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
            if(count($continuous) > 0){
                $ret[0] = 'dontsubmit';
                $errormsg = $errormsg.'<li>Doctor having appointments in other branches also. Check doctor appointment</li>';
            }
            else{
                $btst = date('Y-m-d H:i:s', strtotime( $appointmentdet["end"]) - 3540);$bted = date('Y-m-d H:i:s', strtotime( $appointmentdet["end"]) + 3540);
                $continuous = DB::table("appoinments")->where('appoinmentdate', $apdate)->where('doctorid',$docid)->where('delet','0')->where('branchcode','!=',$branchid)->whereRaw("((appointment_start BETWEEN '".$btst."' AND '".$bted."') OR (appointment_end BETWEEN '".$btst."' AND '".$bted."' ))")->where('branchcode','!=',$branchid)->orderBy('appointment_start', 'ASC');
                if($appid > 0){ $continuous = $continuous->where('appoinments.id', '!=', $appid); }
                $continuous = $continuous->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
                if(count($continuous) > 0){
                    $ret[0] = 'dontsubmit';
                    $errormsg = $errormsg.'<li>Doctor having appointments in other branches also. Check doctor appointment</li>';
                }
            }


            /*check for continuous appointments other branch for host*/
            $btst = date('Y-m-d H:i:s', strtotime( $appointmentdet["start"]) - 3540);$bted = date('Y-m-d H:i:s', strtotime( $appointmentdet["start"]) + 3540);
            $continuous = DB::table("appoinments")->where('appoinmentdate', $apdate)->where('host_name',$host)->where('delet','0')->where('branchcode','!=',$branchid)->whereRaw("((appointment_start BETWEEN '".$btst."' AND '".$bted."') OR (appointment_end BETWEEN '".$btst."' AND '".$bted."' ))")->where('branchcode','!=',$branchid)->orderBy('appointment_start', 'ASC');
            if($appid > 0){ $continuous = $continuous->where('appoinments.id', '!=', $appid); }
            $continuous = $continuous->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
            if(count($continuous) > 0){
                $ret[0] = 'dontsubmit';
                $errormsg = $errormsg.'<li>Host having appointments in other branches also. Check host appointment</li>';
            }
            else{
                $btst = date('Y-m-d H:i:s', strtotime( $appointmentdet["end"]) - 3540);$bted = date('Y-m-d H:i:s', strtotime( $appointmentdet["end"]) + 3540);
                $continuous = DB::table("appoinments")->where('appoinmentdate', $apdate)->where('host_name',$host)->where('delet','0')->where('branchcode','!=',$branchid)->whereRaw("((appointment_start BETWEEN '".$btst."' AND '".$bted."') OR (appointment_end BETWEEN '".$btst."' AND '".$bted."' ))")->where('branchcode','!=',$branchid)->orderBy('appointment_start', 'ASC');
                if($appid > 0){ $continuous = $continuous->where('appoinments.id', '!=', $appid); }
                $continuous = $continuous->whereRaw("'cancelled' != (SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.`appointment_id` = appoinments.id ORDER BY `updated_at` DESC LIMIT 1)")->get();
                if(count($continuous) > 0){
                    $ret[0] = 'dontsubmit';
                    $errormsg = $errormsg.'<li>Host having appointments in other branches also. Check host appointment</li>';
                }
            }

            /*$chkclients = DB::table("appoinments")->select("appoinments.*", "branches.branchname", "appoinment_time.timings")->join('branches', 'branches.branchcode', '=', 'appoinments.branchcode')->join('appoinment_time','appoinment_time.id' ,'=','appoinments.appoinment_time')->where('appoinments.patientid', $clientid)->where('appoinments.appoinmentdate', $apdate)->where('branches.branchcode', "!=", 0);
            $row = $chkclients->get();
            if(!empty($row)) {
                foreach ($row as $chkclient) {
                    $ret[0] = 'checkvalue';
                    $errormsg = $errormsg . '<li>Client already have appoinment in ' . $chkclient->branchname . ' branch at '.$chkclient->timings.'.</li>';
                }
            }*/

            $errormsg = $errormsg.'</ul></div>';
            $ret["html"] = $errormsg;

            return json_encode($ret);
        }else{echo 'not go in';}
    });

    /*Old function to get doctoravailability
     * Route::any('getdoctoravailability/{id}/{appdateval}/{branch}/{client}', function ($id, $appdateval, $branch, $client) {
        if (Auth::User()) {
            //return $id;
            if ($appdateval == 1) $appdateval = date("Y-m-d"); else $appdateval = date('Y-m-d', strtotime($appdateval));
            $day = strtolower(date('l',strtotime($appdateval)));
            $datas = DB::table("appoinments")->select("appoinments.appoinment_time")->where("appoinments.doctorid", "=", $id)->where('appoinments.appoinmentdate', $appdateval)->get();
            $datas1 = DB::table("doctor_availability")->select("doctor_availability.time_id", "doctor_availability.doc_available" )->where("doctor_availability.doctor_id","=",$id)->where("doctor_availability.day","=",$day)->where("doctor_availability.branch_id","=" ,$branch)->get();
            $returnarray = array();
            $i = 0;

            $selday = array( 1=>0,2=>0,3=>0,4=>0,5=>0,6=>0,7=>0,8=>0 );
            //$name = array();

            foreach($datas1 as $dt1){
                if($selday[$dt1->time_id] == 0) {
                    $selday[$dt1->time_id] = $dt1->doc_available;
                }
            }
            //echo '<pre>'.print_r($datas).'</pre>';
            //echo '<pre>'.print_r($selday).'</pre>';
            foreach ($datas as $dt) {
                if($selday[$dt->appoinment_time] == 1)
                {
                    $selday[$dt->appoinment_time] = 0;
                }
            }
            //return count($datas1);
            return Response::json($selday);
        }
    });*/

    Route::any('getdoctoravailability/{id}/{appdateval}/{branch}/{client}', function ($id, $appdateval, $branch, $client) {
        if (Auth::User()) {
            //return $id;
            if ($appdateval == 1) $appdateval = date("Y-m-d"); else $appdateval = date('Y-m-d', strtotime($appdateval));
            $day = strtolower(date('l',strtotime($appdateval)));
            $datas = DB::table("appoinments")->join('users','users.id','=','appoinments.doctorid')->join('registration_details','registration_details.id','=','users.registerid')->join('branches','branches.id','=','appoinments.branchcode')->select("appoinments.appoinment_time", "registration_details.firstname", "branches.branchname")->where("appoinments.doctorid", "=", $id)->where('appoinments.appoinmentdate', $appdateval)->get();
            $datas1 = DB::table("doctor_availability")->select("doctor_availability.time_id", "doctor_availability.doc_available" )->where("doctor_availability.doctor_id","=",$id)->where('appoinments.delet','0')->where("doctor_availability.day","=",$day)->where("doctor_availability.branch_id","=" ,$branch)->get();
            $timings = DB::table('appoinment_time')->select('appoinment_time.id')->get();

            //echo '<pre>'.print_r($datas);exit;
            //Select all timings from table
            $selday = array();


            //Get Oncall option for doctor
            $oncall_opt = 0;
            $oncall = DB::table('users')->select('users.on_call_option')->where('id',$id)->get();
            foreach($oncall as $onc){
                $oncall_opt = $onc->on_call_option;
            }

            if($oncall_opt == 'no'){

                //echo '<pre>'.print_r($selday);exit;
                foreach($timings as $timing){
                    $selday[$timing->id] = 0;
                }

                foreach($datas1 as $dt1){
                    if($selday[$dt1->time_id] == 0) {
                        $selday[$dt1->time_id] = $dt1->doc_available;
                    }
                }
                //echo '<pre>'.print_r($datas).'</pre>';
                //echo '<pre>'.print_r($selday).'</pre>';
                foreach ($datas as $dt) {
                    if($selday[$dt->appoinment_time] == 1)
                    {
                        $selday[$dt->appoinment_time] = 0;
                    }
                }
            }
            elseif($oncall_opt == 'yes'){
                foreach($timings as $timing){
                    $selday[$timing->id] = 1;
                }
                foreach ($datas as $dt) {
                    if($selday[$dt->appoinment_time] == 1)
                    {
                        $selday[$dt->appoinment_time] = 0;
                        $selday['apdet'][$dt->appoinment_time] = ' - Dr. '.$dt->firstname.' - '.$dt->branchname;
                    }
                }
            }
            //echo print_r($selday);exit;
            return Response::json($selday);
        }
    });

    /* Function to get doctors full availability from monday to sunday and display in myaccount page */
    Route::any('docavail/{id}/{branch}', function ($id, $branch){
        if (Auth::User()) {

            $datas = DB::table('doctor_availability')->where('doctor_id', $id)->where('hide', '0')->orderby('time_id','asc')->get();//where('branch_id', $branch)->
            $avail = array();
            $i= 1;$sunday = array( 1=>0,2=>0,3=>0,4=>0,5=>0,6=>0,7=>0,8=>0 );$monday = array( 1=>0,2=>0,3=>0,4=>0,5=>0,6=>0,7=>0,8=>0 );$tuesday = array( 1=>0,2=>0,3=>0,4=>0,5=>0,6=>0,7=>0,8=>0 );$wednesday = array( 1=>0,2=>0,3=>0,4=>0,5=>0,6=>0,7=>0,8=>0 );$thursday = array( 1=>0,2=>0,3=>0,4=>0,5=>0,6=>0,7=>0,8=>0 );$friday = array( 1=>0,2=>0,3=>0,4=>0,5=>0,6=>0,7=>0,8=>0 );$saturday = array( 1=>0,2=>0,3=>0,4=>0,5=>0,6=>0,7=>0,8=>0 );

            foreach ($datas as $dt) {
                if($dt->branch_id == $branch) {
                    $avail[$i]['day'] = $dt->day;
                    $avail[$i]['branch_id'] = $dt->branch_id;
                    $avail[$i]['time_id'] = $dt->time_id;
                    $avail[$i]['doc_available'] = $dt->doc_available;
                    $i++;
                }

                if($dt->day == 'sunday')
                {
                    if($sunday[$dt->time_id] != 1 )
                    {
                        $sunday[$dt->time_id] = $dt->doc_available;
                    }
                }
                elseif($dt->day == 'monday'){
                    if($monday[$dt->time_id] != 1 ) {
                        $monday[$dt->time_id] = $dt->doc_available;
                    }
                }
                elseif($dt->day == 'tuesday'){
                    if($tuesday[$dt->time_id] != 1 ) {
                        $tuesday[$dt->time_id] = $dt->doc_available;
                    }
                }
                elseif($dt->day == 'wednesday'){
                    if($wednesday[$dt->time_id] != 1 ) {
                        $wednesday[$dt->time_id] = $dt->doc_available;
                    }
                }
                elseif($dt->day == 'thursday'){
                    if($thursday[$dt->time_id] != 1 ) {
                        $thursday[$dt->time_id] = $dt->doc_available;
                    }
                }
                elseif($dt->day == 'friday'){
                    if($friday[$dt->time_id] != 1 ) {
                        $friday[$dt->time_id] = $dt->doc_available;
                    }
                }
                elseif($dt->day == 'saturday'){
                    if($saturday[$dt->time_id] != 1 ) {
                        $saturday[$dt->time_id] = $dt->doc_available;
                    }
                }

                $avail['sunday'] = $sunday; $avail['monday'] = $monday; $avail['tuesday'] = $tuesday; $avail['wednesday'] = $wednesday; $avail['thursday'] = $thursday; $avail['friday'] = $friday; $avail['saturday'] = $saturday;
            }

            if(count($datas) == 0){
                $avail[1]['day'] = 'nill';
                $avail[1]['branch_id'] = 'nill';
                $avail[1]['time_id'] = 'nill';
                $avail[1]['doc_available'] = 'nill';
                $avail['sunday'][1] = 'nill';
                $avail['monday'][1] = 'nill';
                $avail['tuesday'][1] = 'nill';
                $avail['wednesday'][1] = 'nill';
                $avail['thursday'][1] = 'nill';
                $avail['friday'][1] = 'nill';
                $avail['saturday'][1] = 'nill';
            }
            return Response::json($avail);
        }
    });

    //Delete Doctor availability from doctor account
    Route::any('deldocavailability/{docid}/{brid}/{day}', function($docid,$brid,$day){
        DB::table('doctor_availability_daywise')->where('user_id',$docid)->where('branchcode',$brid)->where('day', $day)->update(['hide'=>'yes']);
    });

    //Insert Doctor availability from doctor account
    Route::any('upddocavailability/{docid}/{brid}/{day}/{avail}/',function ($docid,$brid,$day,$avail){
        if (Auth::User()) {
            //$i = 1;
            $availarr = explode(',', $avail);
            $ins = DB::table('doctor_availability_daywise')->insert([
                    'user_id' => $docid,
                    'branchcode' => $brid,
                    'day' => $day,
                    'fhour' => $availarr[0],
                    'fmin' => $availarr[1],
                    'fap'=> $availarr[2],
                    'thour'=> $availarr[3],
                    'tmin'=> $availarr[4],
                    'tap'=> $availarr[5],
                    'day_off'=> $availarr[6],
                    'hide'=>'no',
                    'created_by'=> Auth::User()->id,
                    'created_at' => date('Y-m-d H:i:s')
                ]);

            if($ins)
                return "Successfully saved";
            else
                return "Error while saving";
        }
    });
    /*Route::any('upddocavailability/{docid}/{brid}/{day}/{avail1}/',function ($docid,$brid,$day,$avail){
        if (Auth::User()) {
            //$i = 1;
            $postdt = json_decode($avail);
            //var_dump(json_decode($avail));
            // $count = array_count_values($postdt);
            for ($i = 1; $i <= 8; $i++) {
                $count = DB::table('doctor_availability')->where('doctor_id', $docid)->where('branch_id', $brid)->where('day', $day)->where('time_id', $i)->count();
                //echo $count;
                if ($count == 0) {
                    $ins = DB::table('doctor_availability')->insert([
                        'doctor_id' => $docid,
                        'branch_id' => $brid,
                        'day' => $day,
                        'time_id' => $i,
                        'doc_available' => $postdt[$i],
                        'created_date' => date('Y-m-d H:i:s')
                    ]);
                } elseif ($count > 0) {
                    $ins = DB::table('doctor_availability')->where('doctor_id', $docid)->where('branch_id', $brid)->where('day', $day)->where('time_id', $i)->update([
                        'doctor_id' => $docid,
                        'branch_id' => $brid,
                        'day' => $day,
                        'time_id' => $i,
                        'doc_available' => $postdt[$i]
                    ]);
                }
            }

            return "Successfully saved";
        }
    });*/

    //Function to save doctor profile data
    Route::get('savedocprofile/{nametitle}/{firstname}/{lastnametitle}/{lastname}/{docid}', function ($nametitle,$firstname,$lastnametitle, $lastname,$docid){
        if (Auth::User()) {
            $lastnametitle = str_replace("_", "/", $lastnametitle);

            $data = DB::table('registration_details')->where('id', $docid)->update(['nametitle' => $nametitle, 'firstname' => $firstname, 'lastnametitle' => $lastnametitle, 'lastname' => $lastname ]);
            return 1;
        }else{
            return 0;
        }
    });

    //Function to save doctor email id
    Route::get('savedocemail/{emailid}/{docid}', function ($emailid,$docid){
        if (Auth::User()) {
            //$count = DB::table('users')->where('email', $emailid)->count();
            /*if($count == 0) {*/
                $data = DB::table('users')->where('id', $docid)->update(['email' => $emailid]);
                return 1;
            /*}
            else
                return 0;*/
        }
    });

    //Save user mobile ajax
    Route::get('savedocmob/{mob}/{docid}', function ($mob,$docid){
        if (Auth::User()) {
            /*$count = DB::table('users')->where('Mobile_number', $mob)->count();
            if($count == 0) {*/
                $data = DB::table('users')->where('id', $docid)->update(['Mobile_number' => $mob]);
                return 1;
            /*}
            else
                return 0;*/
        }
    });

    //Function to save doctor contact details
    Route::get('updatedoccomm/{mobile}/{voicecall}/{sms}/{whatsapp}/{priority}/{contid}', function ($mobile,$voicecall,$sms,$whatsapp,$priority,$conid){
        if (Auth::User()) {
            $data = DB::table('doctor_communication')->where('id',$conid)->update(['contactnumber' => $mobile, 'voice_call' => $voicecall, 'sms'=> $sms, 'whatsapp' => $whatsapp,'priority'=> $priority]);
            return 1;
        }
    });

    Route::get('deletestaff/{id}/{user}', function ($id,$user) {
        if (Auth::User()->Role == 'admin' ) {
            if($user == 'Doctor'){
                $check_staff = DB::table('appoinments')->where('doctorid', $id)->get();
            }
            elseif($user == 'Host'){
                $check_staff = DB::table('appoinments')->where('host_name', $id)->get();
            }
            else{
                $check_staff =0;
            }

            if($check_staff){
                \session()->flash('alert-danger', "This Staff involved in some of your appointments. Can't delete.");
                return redirect()->action('StaffController@index');
            }
            else{
                //$data = DB::table('users')->where('id', $id)->delete();
                //$data = DB::table('registration_details')->where('id', $id)->delete();
                $data = DB::table('users')->join('registration_details','registration_details.id', '=', 'users.registerid')->where('users.id', $id)->delete();

                \session()->flash('alert-success', 'Employee deleted successfully!');
                if($user == 'Doctor') {
                    return redirect()->action('DoctorController@index');
                }
                elseif($user == 'Host'){
                    return redirect()->action('HostController@index');
                }
                else{
                    return redirect()->action('StaffController@index');
                }
            }
        }
        elseif(Auth::User()->Role == 'super_admin'){

            $check_staff = DB::table('users')->join('registration_details','registration_details.id', '=', 'users.registerid')->where('users.id', $id)->update(['users.delet'=>'1', 'registration_details.delet'=>'1']);
            if($check_staff){
                \session()->flash('alert-success', 'Employee deleted successfully!');
                return redirect()->action('StaffController@index');
            }
            else{
                //$data = DB::table('users')->where('id', $id)->delete();
                //$data = DB::table('registration_details')->where('id', $id)->delete();
                $data = DB::table('users')->join('registration_details','registration_details.id', '=', 'users.registerid')->where('users.id', $id)->delete();

                \session()->flash('alert-danger', "This Staff involved in some of your appointments. Can't delete.");
                return redirect()->action('StaffController@index');
            }
        }
        else{
            return redirect('myaccount');
        }
    });
    Route::get('deleteuser/{id}', function ($id) {
        if (Auth::User()->Role == 'admin') {

            $check_user = DB::table('appoinments')->where('patientid', $id)->where('delet', 0)->get();
            if($check_user){
                \session()->flash('alert-danger', "This client involved in some of your appointments. You can block Can't delete.");
                return redirect()->action('usrlistingController@index');
            }
            else {
                /*$data = DB::table('users')->where('id', $id)->delete();
                $data = DB::table('registration_details')->where('id', $id)->delete();*/
                $data = DB::table('users')->join('registration_details', 'registration_details.id', '=', 'users.registerid')->where('users.id', $id)->delete();
                \session()->flash('alert-success', 'Client deleted successfully!');
                return redirect()->action('usrlistingController@index');
            }
        }
        elseif( Auth::User()->Role == 'super_admin'){

            //$res = DB::raw('users1')->join('registration_details','registration_details.id','=','users.registerid')->join('appoinments', 'appoinments.patientid','=', 'users.id')->join('inspection_details','inspection_details.appoinment_id','=','appoinments.id')->join('inspection_procedure','inspection_procedure.inspection_id','=','inspection_details.id')->where('users.id', $id)->delete('users','registration_details','appoinments','inspection_details','inspection_procedure');
            $res = DB::statement("DELETE users, registration_details, appoinments, inspection_details, inspection_procedure FROM users JOIN registration_details ON registration_details.id = users.registerid JOIN appoinments ON appoinments.patientid=users.id JOIN inspection_details ON inspection_details.appoinment_id=appoinments.id JOIN inspection_procedure ON inspection_procedure.inspection_id=inspection_details.id WHERE users.id = '$id'");
            if($res){
                $res = DB::select("DELETE appoinments FROM appoinments WHERE appoinments.patientid = '$id'");
                \session()->flash('alert-success', 'Client deleted successfully!');
                return redirect('userlisting');
            }else{
                \session()->flash('alert-danger', 'Problem while deleting try again!');
                return redirect('userlisting');
            }
        }
        else{
            return redirect('myaccount');
        }
    });

//Apprvove User
    Route::get('approveuser/{id}/{status}', function ($id, $status) {
        if (Auth::User()->Role == 'admin' || Auth::User()->Role == 'super_admin' || Auth::User()->Role == 'Host') {

            $userdet = DB::table('users')->join('registration_details', 'registration_details.id', '=', 'users.registerid')->where('users.id', $id)->get();


            if ($status == 0) {

                foreach ($userdet as $data) {

                    $usercnt = DB::table('users')->join('registration_details', 'registration_details.id', '=', 'users.registerid')->where('users.created', date('Y-m-d'))->where('registration_details.branchcode', $data->branchcode)->count();
                    $usercnt = $usercnt + 1;
                    $f2d = sprintf("%02d", $usercnt);
                    $brcode = sprintf("%02d", $data->branchcode);
                    $nme = strtoupper(substr(preg_replace('/[^A-Za-z\-]/', '', $data->firstname), 0, 2));
                    $dt = date('dmy');
                    $username = $f2d . $brcode . $nme . $dt;
                /*$data1 = DB::table('users')->where('id', $id)->update(['approval' => 1, 'name' => $username]);*/

                $data1 = DB::table('users')->where('id', $id)->update(['approval' => 1]);

                    Mail::send('emails.approval', ['data' => $data, 'username' => $username], function ($mail) use ($data) {
                        $mail->to($data->email, $data->name)->from(Auth::user()->email)->subject('Your User Id Approved in Evident Dental.');
                    });

                    \session()->flash('alert-success', 'Client Approved !');
                }
            } elseif ($status == 1) {

                $userdet = DB::table('users')->join('registration_details', 'registration_details.id', '=', 'users.registerid')->where('users.id', $id)->get();
                foreach ($userdet as $data) {

                    $usercnt = DB::table('users')->join('registration_details', 'registration_details.id', '=', 'users.registerid')->where('users.created', date('Y-m-d'))->where('registration_details.branchcode', $data->branchcode)->count();
                    $usercnt = $usercnt + 1;
                    $f2d = sprintf("%02d", $usercnt);
                    $brcode = sprintf("%02d", $data->branchcode);
                    $nme = strtoupper(substr(preg_replace('/[^A-Za-z\-]/', '', $data->firstname), 0, 2));
                    $dt = date('dmy');
                    $username = $f2d . $brcode . $nme . $dt;
                    /*$data1 = DB::table('users')->where('id', $id)->update(['approval' => 1, 'name' => $username]);*/

                    $data1 = DB::table('users')->where('id', $id)->update(['approval' => 0]);

                    Mail::send('emails.blocked', ['data' => $data, 'username' => $username], function ($mail) use ($data) {
                        $mail->to($data->email, $data->name)->from(Auth::user()->email)->subject('Your Account Blocked by Administrator.');
                    });

                    \session()->flash('alert-success', 'Client Blocked !');
                }
            }
            return redirect()->action('usrlistingController@index');
        }
    });

    //Function to save donot dusturb timings for doctor
        Route::get('savedonot/{doctor}/{day}/{times}', function($doctor,$day,$times){
            if(Auth::User()){
                $timings = json_decode($times);
                DB::table('doctor_donot_disturb')->where('doctor_id','=',$doctor)->where('day','=',$day)->delete();
                //return count($times);
                foreach($timings as $time){
                    DB::table('doctor_donot_disturb')->insert(['doctor_id'=>$doctor, 'day' => $day, 'timings'=>$time,'created_at' => date("Y-m-d H:i:s")] );
                }
                return 1;
            }
        });

    //Function to check payment info while update the payment info
    //Route::get('checkpayment')

    //Function to save oncall option
    Route::get('saveoncall/{docid}/{chkcall}', function($docid,$chkcall){
        if(Auth::User()){
            $ret = DB::table('users')->where('id',$docid)->update(['on_call_option'=> $chkcall]);
            return $ret;
        }
    });

    Route::get('saveprocedure/{userid}/{procedure}/{price}', function($userid, $procedure, $price){
        if(Auth::User()->Role == 'Doctor'){
            $ret = DB::table('doctor_procedure_price')->where('dotor_id', $userid)->where('procedure_name',$procedure)->update(['price_to'=>date('Y-m-d'), 'hide'=>'yes','updated_by'=>Auth::User()->id]);
            $ret = DB::table('doctor_procedure_price')->insert(['dotor_id'=> $userid, 'procedure_price'=>$price,'procedure_name'=>$procedure,'price_from'=>date('Y-m-d'),'created_by'=>Auth::User()->id, 'hide'=>'no']);
            return json_encode($ret);
        }
    });

//Route::get('admin/userlisting',
//    ['as' => 'list of user',
//    'uses' => 'usrlistingController@index']
//);

//// Authentication routes...
//Route::get('auth/login', 'Auth\AuthController@getLogin');
//Route::post('auth/login', 'Auth\AuthController@postLogin');
//Route::get('auth/logout', 'Auth\AuthController@getLogout');
//
//// Registration routes...
//Route::get('auth/register', 'Auth\AuthController@getRegister');
//Route::post('auth/register', 'Auth\AuthController@postRegister');
//
////Route::get('index', [
////    'as' => 'index',
////    'uses' => 'PagesController@getIndex'
////]);
//
    Route::resource('registration', 'RegistrationController');
    Route::resource('myaccount', 'MyaccountController');
    Route::resource('userlisting', 'usrlistingController');
    Route::resource('edituser', 'UserController');
    Route::resource('stafflisting', 'StaffController');
    Route::resource('editstaff', 'StaffController');
    Route::resource('fixappoinment', 'AppoinmentController');
    Route::resource('quickreg', 'UserController');
    Route::resource('editappoinment', 'AppoinmentController');
    Route::resource('doccommunication', 'doctorcommunication');
    Route::resource('sourceofref', 'SourceController');
    Route::resource('quickregistration', 'QuickregistrationController');
    Route::resource('inspection_details', 'InspectionController');
    Route::resource('inspectionlist','InspectionController');
    Route::resource('procedures', 'ProcedureController');
    Route::resource('remainders', 'RemainderController');
    Route::resource('doctors', 'DoctorController');
    Route::resource('hosts', 'HostController');
    Route::resource('doctorprocedureprice', 'DocProcedurePriceController');
    Route::resource('client', 'ClientController');

    Route::any('sample_app', [
        'as' => 'sample',
        'uses' => 'PagesController@sample'
    ]);

    Route::any('hostavailability',[
        'as' => 'hostavailability',
        'uses' => 'HostController@hostavailability'
    ]);

    Route::any('changestatus',[
        'as' => 'changestatus',
        'uses' => 'AppoinmentController@updatestatus'
    ]);
//Route::resource('/', 'Auth\AuthController');

    Route::controllers([
        'auth' => 'Auth\AuthController',
        'password' => 'Auth\PasswordController',

    ]);

    Route::any('myappointments',[
       'as' => 'appointments',
        'uses' => 'ClientController@myappointments'
    ]);

    Route::any('changepassword',[
        'as' => '',
        'uses' => 'PagesController@changepassword'
    ]);

    Route::any('resetpassword',[
        'as' => '',
        'uses' => 'PagesController@resetpassword'
    ]);
//Delete appoinments

    Route::any('deleteappoinments', [
        'as' => "deleteapponment",
        'uses' => "AppoinmentController@deleteappoinments"
    ]);

    //Update inspection data
    Route::any('update_inspection',[
        'as' => "updateinspection",
        'uses' => "InspectionController@update"
    ]);

//Source of References
    Route::post('add_soureofref',
        ['as' => 'add_sourceofref', 'uses' => 'SourceController@store']);
//Delete Source

//Delete users
    Route::any('deletebulkuser', [
        'as' => "deletebulkuser",
        'uses' => "usrlistingController@deleteuser"
    ]);
    Route::any('deletebulkstaff', [
        'as' => "deletebulkstaff",
        'uses' => "StaffController@deletebulkstaff"
    ]);

    //Define routes for address informations
    Route::get('api/dependent-dropdown','APIController@index');
    Route::get('api/get-state-list','APIController@getStateList');
    Route::get('api/get-city-list','APIController@getCityList');

    Route::any('appointmentdetails/{id}/', function($id){
        $clientdata = array();
        if(Auth::Check()) {
            if (Auth::User()->Role == 'Client' || Auth::User()->Role == 'super_admin')
            {
                $appoinment = DB::table('appoinments')->select(DB::raw("(SELECT CONCAT(nametitle,'',firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.patientid = users.id) AS patientname"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT firstname FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.doctorid = users.id) As doctorname"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT CONCAT(nametitle,'',firstname) FROM registration_details INNER JOIN users ON registration_details.id = users.registerid WHERE appoinments.host_name = users.id) As hostname"));
                $appoinment = $appoinment->addSelect(DB::raw("inspection_details.*,  appoinments.appointment_start"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT GROUP_CONCAT(procedure_name SEPARATOR ',') AS procedures FROM inspection_procedure WHERE inspection_procedure.inspection_id = inspection_details.id) AS procedures"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT branchname FROM branches WHERE branches.id = appoinments.branchcode) AS branchcode"));
                $appoinment = $appoinment->addSelect(DB::raw("(SELECT appointment_status.appointment_status FROM appointment_status WHERE appointment_status.appointment_id = appoinments.id ORDER BY appointment_status.created_at DESC LIMIT 1) As status"));
                /*$appoinment = $appoinment->join('appoinments','appoinments.id','=','inspection_details.appoinment_id','left');*/
                $appoinment = $appoinment->join('inspection_details','inspection_details.appoinment_id','=','appoinments.id','left');
                $appoinment = $appoinment->where('appoinments.id',$id);
                $appoinmentlist = $appoinment->get();

                foreach ($appoinmentlist as $v) {
                    //$return_array[] = array('value'=> $v->firstname);
                    $name['id'] = $v->appoinment_id;
                    $name['clientname'] = ucwords($v->patientname);
                    $name['datetime'] = date('F j, Y, g:i a', strtotime($v->appointment_start));
                    $name['branch'] = ucwords($v->branchcode);
                    $name['docname'] = ucwords($v->doctorname);
                    $name['hostname'] = ucwords($v->hostname);
                    $name['status'] = ucwords($v->status);
                    $name['login'] = $v->client_login_time;
                    $name['prstart'] = $v->proc_start_time;
                    $name['prend'] = $v->proc_end_time;
                    $name['chiefcomp'] = ucfirst($v->chief_complaint);
                    $name['diagnosis'] = ucfirst($v->diagnosed_complaint);
                    $name['otherfindings'] = str_replace('*', ', ',$v->other_findings);
                    $name['nextapppurpose'] = ucfirst($v->purpose_nxt_app);
                    $name['procedures'] = $v->procedures;
                    $name['tot_pay'] = round($v->final_price);
                    $name['paid'] = round($v->client_payment);
                    $name['balance'] = round($v->balance_price);
                    $name['clientnote'] = ucfirst($v->client_note);

                    array_push($clientdata, $name);
                }
            }
        }
        return json_encode($clientdata);
    });

    //Block to get time for procedure
    Route::any('proceduremgmt/{appid}/{info}', function($appid, $info){
        if(Auth::check()){
            if($info == 'loggedin') $column = 'client_login';elseif($info == 'prstart') $column = 'proc_start';elseif($info == 'prend') $column = 'proc_end';
            $proceduredet = \App\FixAppoinment::find($appid);
            $proceduredet->$column = date('Y-m-d H:i:s');
            $sv = $proceduredet->save();
            if($sv){
                echo '<span class="tim">'.date('d-m-Y H:i').'</span>';
            }else{
                echo "Cant take time";
            }
        }else{
            $val = "User not logged in. Kindly refresh the page";
            echo $val;
        }
    });

    //GEt time information
    Route::any('getprtimeinfo/{appid}', function($appid){
        $val = array();
        if(Auth::check()){
            $prdet = \App\FixAppoinment::where('id','=',$appid)->first();
            if($prdet->client_login == 0){ $login = 0; }else{ $login = date('d-m-Y H:i', strtotime($prdet->client_login));}
            if($prdet->proc_start == 0){ $prst = 0; }else{ $prst = date('d-m-Y H:i', strtotime($prdet->proc_start));}
            if($prdet->proc_end == 0){ $prend = 0; }else{ $prend = date('d-m-Y H:i', strtotime($prdet->proc_end));}
            $val[0] = $login;
            $val[1] = $prst;
            $val[2] = $prend;
        }
        echo json_encode($val);
    });
});