<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sourceofreference_model extends Model
{
    //Registration Table configuration
    protected $table = 'sourceofreference';
    protected $fillable = ['sourceofreference','created_by','created_date','updated_date','updated_by','hide'];
}
