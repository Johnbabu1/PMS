<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class registration extends Model
{
    //Registration Table configuration
    protected $table = 'registration_details';
    protected $fillable = ['nametitle','firstname','lastnametitle','lastname','surname','gender','dob','qualification','designation','company_name','address_line_1','address_line_2','area','country','state','city','pincode','branchcode','sourceofreference','referredby','created_by','updated_by','delet'];
}
