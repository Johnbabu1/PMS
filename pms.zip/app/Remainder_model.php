<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Remainder_model extends Model
{
    //Registration Table configuration
    protected $table = 'remainders';
    protected $fillable = ['user_id','remainder_title','remainder_place','remainder_description','remainder_date','remainder_time','created_at','updated_at','created_by','updated_by'];
}
