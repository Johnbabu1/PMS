<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class appoinment_timemodel extends Model
{
    //
    protected $table = 'appoinment_time';
    protected $fillable = ['timings','created_at','updated_at'];
}
