<?php
namespace App\Helper;
use DB;
use App\Remainder_model;
use Illuminate\Support\Facades\Auth;
use App\Http;
use App\User;
use App\registration;

Class userdet
{
    public $Id;
    public $UserId;
    public $Password;
    public $Email;
    public $MobileNumber;
    public $RegisterId;
    public $Role;
    public $OnCallOption;
    public $NameTitle;
    public $FirstName;
    public $LastNameTitle;
    public $LastName;
    public $Gender;
    public $Dob;
    public $Designation;
}
class Helper
{
    public static function notificationCount()
    {
        $remainder = new Remainder_model();
        $remaindercnt = $remainder::where('user_id', Auth::user()->id)->where('status', 'active')->count();
        return $remaindercnt;
    }

    public static function userdata() {
        $accountdetails = new User;
        $userdetails = new registration;
        $allvalue = $userdetails::find(Auth::user()->registerid);
        $account = $accountdetails::find(Auth::user()->id);

        $userdata = new userdet();
        $userdata->Id = $account->id;
        $userdata->UserId = $account->name;
        $userdata->Password = $account->password;
        $userdata->Email = $account->email;
        $userdata->MobileNumber = $account->Mobile_number;
        $userdata->RegisterId = $account->registerid;
        $userdata->Role = $account->Role;
        $userdata->OnCallOption = $account->on_call_option;
        $userdata->NameTitle = $allvalue->nametitle;
        $userdata->FirstName = $allvalue->firstname;
        $userdata->LastNameTitle = $allvalue->lastnametitle;
        $userdata->LastName = $allvalue->lastname;
        $userdata->Gender = $allvalue->gender;
        $userdata->Designation = $allvalue->designation;
        $userdata->Dob = $allvalue->dob;
        return $userdata;
    }
}
?>