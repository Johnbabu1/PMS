<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppointmentStatusModel extends Model
{
    //
    protected $table = 'appointment_status';
    protected $fillable = ['id','appointment_id','status_reason','appointment_status','created_by','created_at','updated_at'];
}
