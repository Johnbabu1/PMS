<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Proceduredetails_model extends Model
{
    //Registration Table configuration
    protected $table = 'procedure_details';
    protected $fillable = ['procedure_name','procedure_price','hide','created_by','created_at','updated_by','updated_at'];
}
