<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FixAppoinment extends Model
{
    //
    protected $table = 'appoinments';
    protected $fillable = ['id','doctorid','patientid','appoinmentdate','appoinment_time','branchcode','clientnote','host_name','appointment_desc','appointment_start','appointment_end','client_login','proc_start','proc_end','created_at','updated_at','created_by','updated_by'];
}
