<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Inspectionprocedure_model extends Model
{
    //Registration Table configuration
    protected $table = 'inspection_procedure';
    protected $fillable = ['inspection_id','procedure_name','procedure_price','doctor_price','procedure_type','created_by','created_at','updated_at','updated_by'];
}
