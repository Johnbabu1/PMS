<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DoctorprocedurePrice extends Model
{
    //Registration Table configuration
    protected $table = 'doctor_procedure_price';
    protected $fillable = ['dotor_id','procedure_name','procedure_price','price_from','price_to','created_by','created_at','updated_by','updated_at','hide'];
}
