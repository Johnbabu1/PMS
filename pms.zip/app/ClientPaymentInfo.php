<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClientPaymentInfo extends Model
{
    //
    protected $table = 'client_payment_info';
    protected $fillable  = ['id','patient_id','appointment_id','final_price','paid_payment','balance_payment','paid_date','created_at','updated_at','created_by','updated_by'];
}
