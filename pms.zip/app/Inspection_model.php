<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Inspection_model extends Model
{
    //Registration Table configuration
    protected $table = 'inspection_details';
    protected $fillable = ['appoinment_id','client_login_time','proc_start_time','proc_end_time','chief_complaint','diagnosed_complaint','other_findings','purpose_nxt_app','client_note','doctor_note','host_note','total_price','concession_type','concession','balance_price','final_price','client_payment','payment_mode','upcoming_price','next_appoinment_id','created_by','created_at','updated_by','updated_at'];
}
