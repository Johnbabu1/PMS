<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class doctoravailability extends Model
{
    //
    protected $table = 'doctor_availability_daywise';
    protected $fillable  = ['user_id','branchcode','day','fhour','fmin','fap','thour','tmin','tap','day_off','created_by','created_at','updated_by','updated_at'];
}
